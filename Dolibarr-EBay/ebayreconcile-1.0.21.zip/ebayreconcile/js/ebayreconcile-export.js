/* Audit-friendly CSV/JSON export helpers. */
(function (root) {
    function money(value) {
        var n = Number(value || 0);
        return isFinite(n) ? Math.round(n * 100) / 100 : 0;
    }

    function optionalMoney(value) {
        return value === null || value === undefined ? null : money(value);
    }

    function docKey(doc) {
        return doc.id ? 'id:' + doc.id : [doc.type || '', doc.ref || '', money(doc.total_ht)].join(':');
    }

    function rowNeedsAction(row) {
        return (row.status === 'MISMATCH' && !row._adjusted)
            || (row.status === 'MATCH' && !row._adjusted && Math.abs(Number(row.diff || 0)) > 0.01)
            || (row.status === 'MISSING_IN_DOLIBARR' && !row._adjusted && !row._excluded)
            || (row.status === 'NO_LINKED_INVOICES' && !row._adjusted && !row._excluded)
            || (row.status === 'NO_ORDER_NUMBER' && !row._adjusted && !row._excluded);
    }

    function build(results, totals, payout, sourceFile) {
        var orders = (results || []).map(function (row) {
            var excluded = !!row._excluded;
            var resolved = excluded || !!row._adjusted;
            var status = resolved ? 'MATCH' : (row.status || '');
            var ebayNetRow = money(row.ebay_net);
            // Use the backend's reconciliation net (amount DUE), which correctly
            // excludes invoices settled in an earlier payout cycle. Do NOT re-derive
            // from document gross — that re-includes prior-cycle invoices and breaks
            // partial-refund orders. The paid-payout re-view case (where due collapses
            // to 0) is handled instead by replaying the settled state_json.
            // A created adjustment or approved exclusion completes this row. Some
            // saved browser states still carry the pre-action dolibarr_net value;
            // exporting that stale value made settled reports show a false gap.
            var dolNetRow = resolved ? ebayNetRow : money(Number(row.dolibarr_net || 0));
            return {
                status: status,
                order_number: row.order_number || '',
                ebay_type: row.ebay_type || (row.ebay_types || []).join(' / '),
                ebay_net: ebayNetRow,
                dolibarr_net: dolNetRow,
                // Always derive difference from the two columns shown, so every row
                // (and the column totals) is internally consistent: difference ==
                // ebay_net - dolibarr_net, no exceptions. The old `excluded ? 0`
                // override zeroed the difference while leaving dolibarr_net intact,
                // which is exactly why the CSV column sums didn't tie out.
                difference: resolved ? 0 : money(ebayNetRow - dolNetRow),
                dolibarr_order_ref: row.dolibarr_order_ref || '',
                dolibarr_order_id: row.dolibarr_order_id || '',
                document_count: (row.invoices || []).length,
                resolution: excluded ? 'excluded_zero_balance' : (row._adjusted ? 'document_created' : ''),
                notes: row.notes || '',
            };
        });

        var seen = {};
        var documents = [];
        (results || []).forEach(function (row) {
            (row.invoices || []).forEach(function (doc) {
                var key = docKey(doc);
                if (seen[key]) return;
                seen[key] = true;
                var sourceAmount = money(doc.total_ht);
                var amount = doc.type === 'credit_note' ? -Math.abs(sourceAmount) : Math.abs(sourceAmount);
                // remain_to_pay = amount still owed on this document; kept for the
                // paid column and PAY ALL. It is NOT the reconciliation basis (see
                // dolibarr_gross_transaction below - that uses the gross amount).
                // Credit notes affect reconciliation but are not invoices to pay.
                var remain = doc.type === 'credit_note' ? 0 : money(doc.remain_to_pay);
                var isPaid = doc.type === 'credit_note' || !!doc.is_paid || Math.abs(remain) <= 0.01;
                documents.push({
                    status: row.status || '',
                    order_number: row.order_number || '',
                    dolibarr_order_ref: row.dolibarr_order_ref || '',
                    document_id: doc.id || '',
                    document_ref: doc.ref || '',
                    document_type: doc.type || '',
                    document_amount: amount,
                    // Reconciliation basis = the document's GROSS amount, not the
                    // amount still due (remain_to_pay). What "reconciled" means is
                    // that the Dolibarr paperwork (invoices - credit notes) equals
                    // the eBay payout - a fact about the documents, independent of
                    // whether they've been paid yet. Using remain_to_pay broke this:
                    // once invoices are paid (or when re-viewing an already-settled
                    // payout) their remain is 0, so they vanished from the net and a
                    // fully-correct payout showed "not reconciled" forever. Payment
                    // status is tracked separately (paid column / PAY ALL).
                    dolibarr_gross_transaction: doc.type === 'invoice' ? Math.abs(amount) : 0,
                    dolibarr_adjustment: doc.type === 'credit_note' ? Math.abs(amount) : 0,
                    remain_to_pay: remain,
                    is_paid: isPaid,
                    notes: '',
                });
            });
        });

        // Collapse duplicate invoices: when an order/amount already has a fully-paid
        // invoice, an additional UNPAID invoice for the same order/amount is a stray
        // record that should not exist (it is not a real obligation). Showing it as
        // "NO (… left)" misrepresents the order as partly unpaid, so we drop it from
        // the document rows and totals and keep one transparent note instead. The
        // order itself is represented by the genuine, already-paid invoice.
        var invoiceGroups = {};
        documents.forEach(function (d) {
            if (d.document_type !== 'invoice') return;
            // Only collapse within a known order. An amount-only bucket would group
            // invoices from DIFFERENT orders that happen to share an amount, and a
            // single paid one could then drop genuine unpaid invoices elsewhere.
            if (!d.order_number) return;
            var key = d.order_number + '|' + Math.abs(d.document_amount);
            (invoiceGroups[key] = invoiceGroups[key] || []).push(d);
        });
        var duplicatesIgnored = [];
        Object.keys(invoiceGroups).forEach(function (key) {
            var group = invoiceGroups[key];
            if (group.length < 2) return;
            var hasPaid = group.some(function (d) { return d.is_paid; });
            if (!hasPaid) return; // no paid twin → not a settled duplicate, leave as-is
            group.forEach(function (d) {
                if (!d.is_paid) {
                    duplicatesIgnored.push(d);
                }
            });
        });
        if (duplicatesIgnored.length) {
            // Filter by object identity: duplicatesIgnored holds the same row
            // references that live in `documents`. (docKey() must NOT be used here
            // - it reads id/ref/type/total_ht, which exist only on the raw invoice
            // objects, not on these transformed rows, so it would collapse every
            // row to one key and drop the entire set.)
            documents = documents.filter(function (d) {
                return duplicatesIgnored.indexOf(d) === -1;
            });
        }

        var ebayNet = totals && totals.netPayout !== null && totals.netPayout !== undefined
            ? money(totals.netPayout)
            : money(orders.reduce(function (sum, row) { return sum + row.ebay_net; }, 0));
        // Reconciliation basis = the per-order Dolibarr net the matcher already
        // computed (orders[].dolibarr_net), summed - NOT a re-total of the raw
        // document rows. A document's gross (e.g. a full customer invoice) routinely
        // dwarfs the eBay-net portion of the order, so summing document amounts can
        // never tie to the payout; the backend's per-order net is the eBay-comparable
        // figure (sum(dolibarr_net) == sum(ebay_net) whenever every row MATCHes).
        // Split by sign for the invoices(+)/credits(-) display so inv - cred == net.
        var dolibarrGross = money(orders.reduce(function (sum, row) {
            return sum + (row.dolibarr_net > 0 ? row.dolibarr_net : 0);
        }, 0));
        var dolibarrAdjustments = money(orders.reduce(function (sum, row) {
            return sum + (row.dolibarr_net < 0 ? -row.dolibarr_net : 0);
        }, 0));
        var dolibarrDocumentNet = money(orders.reduce(function (sum, row) {
            return sum + row.dolibarr_net;
        }, 0));
        var unresolvedCount = (results || []).filter(rowNeedsAction).length;
        var dolibarrOutstanding = money((results || []).reduce(function (sum, row) {
            return rowNeedsAction(row) ? sum + Number(row.diff || 0) : sum;
        }, 0));
        var workflowReconciled = unresolvedCount === 0 && Math.abs(dolibarrOutstanding) <= 0.01;
        var paidAll = workflowReconciled && !documents.some(function (doc) {
            return doc.document_type === 'invoice' && !doc.is_paid && Math.abs(Number(doc.remain_to_pay || 0)) > 0.01;
        });

        return {
            metadata: {
                source_file: sourceFile || '',
                payout_id: payout && payout.id ? payout.id : '',
                payout_date: payout && payout.date ? payout.date : '',
                payout_method: payout && payout.method ? payout.method : '',
            },
            summary: {
                ebay_net_payout: ebayNet,
                ebay_stated_payout: totals ? optionalMoney(totals.statedPayout) : null,
                ebay_gross_sales: totals ? optionalMoney(totals.grossSales) : null,
                ebay_debits: totals ? optionalMoney(totals.debits) : null,
                ebay_credits: totals ? optionalMoney(totals.credits) : null,
                dolibarr_gross_transactions: dolibarrGross,
                dolibarr_adjustments: dolibarrAdjustments,
                dolibarr_document_net: dolibarrDocumentNet,
                raw_dolibarr_document_net: dolibarrDocumentNet,
                dolibarr_outstanding: dolibarrOutstanding,
                unresolved_rows: unresolvedCount,
                workflow_reconciled: workflowReconciled,
                paid_all: paidAll,
                ebay_minus_dolibarr_documents: dolibarrOutstanding,
                documents_reconciled: workflowReconciled,
                ties_out_to_ebay_payout: totals ? totals.tiesOut : null,
                ebay_tie_difference: totals ? optionalMoney(totals.tieDiff) : null,
                duplicate_invoices_ignored: duplicatesIgnored.length,
                duplicate_invoice_refs: duplicatesIgnored.map(function (d) {
                    return d.document_ref || d.document_id;
                }),
            },
            column_totals: computeColumnTotals(orders, documents),
            orders: orders,
            documents: documents,
            duplicates: duplicatesIgnored,
        };
    }

    // Per-column sums for the detail table: order rows carry the eBay/Dolibarr net
    // figures, document rows carry the document-amount figures. Summed separately so
    // the CSV/JSON can show a TOTALS line (and so the eBay-net vs Dolibarr-net gap is
    // visible right under the columns it comes from).
    function computeColumnTotals(orders, documents) {
        var so = function (k) { return money((orders || []).reduce(function (s, r) { return s + Number(r[k] || 0); }, 0)); };
        var sd = function (k) { return money((documents || []).reduce(function (s, d) { return s + Number(d[k] || 0); }, 0)); };
        return {
            ebay_net: so('ebay_net'),
            dolibarr_net: so('dolibarr_net'),
            difference: so('difference'),
            document_amount: sd('document_amount'),
            dolibarr_gross_transaction: sd('dolibarr_gross_transaction'),
            dolibarr_adjustment: sd('dolibarr_adjustment'),
            remain_to_pay: sd('remain_to_pay'),
        };
    }

    function csvCell(value) {
        if (value === null || value === undefined) return '';
        var text = String(value);
        return /[",\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
    }

    function csvRow(values) {
        return values.map(csvCell).join(',');
    }

    // Human-readable pay status for the CSV: "YES" once fully paid, otherwise
    // "NO (X.XX left)" so an auditor sees at a glance how much is still owed.
    function paidStatus(doc) {
        if (doc.document_type === 'credit_note') return 'N/A';
        if (doc.is_paid) return 'YES';
        var left = Math.abs(money(doc.remain_to_pay));
        return 'NO (' + left.toFixed(2) + ' left)';
    }

    function normalize(report) {
        report = report || {};
        report.metadata = report.metadata || {};
        report.summary = report.summary || {};
        report.orders = report.orders || [];
        report.documents = report.documents || [];
        report.duplicates = report.duplicates || [];
        report.documents.forEach(function (doc) {
            if (doc.document_type === 'credit_note') {
                doc.remain_to_pay = 0;
                doc.is_paid = true;
            } else {
                doc.remain_to_pay = money(doc.remain_to_pay);
                doc.is_paid = !!doc.is_paid || Math.abs(doc.remain_to_pay) <= 0.01;
            }
        });

        var s = report.summary;
        // Normalize older saved reports whose resolved rows retained pre-action
        // Dolibarr values. History downloads pass through here, so they receive the
        // same corrected zero-difference representation as newly built reports.
        report.orders.forEach(function (row) {
            var resolution = row.resolution || '';
            var resolved = resolution === 'document_created' || resolution === 'excluded_zero_balance';
            var ebay = money(row.ebay_net);
            if (resolved) {
                row.status = 'MATCH';
                row.dolibarr_net = ebay;
                row.difference = 0;
            } else {
                row.dolibarr_net = money(row.dolibarr_net);
                row.difference = money(ebay - row.dolibarr_net);
            }
        });

        var unresolved = 0;
        var outstanding = 0;
        report.orders.forEach(function (row) {
            var status = row.status || '';
            var resolution = row.resolution || '';
            var resolved = resolution === 'document_created' || resolution === 'excluded_zero_balance';
            var needsAction = !resolved && (
                status === 'MISMATCH'
                || status === 'MISSING_IN_DOLIBARR'
                || status === 'NO_LINKED_INVOICES'
                || status === 'NO_ORDER_NUMBER'
                || (status === 'MATCH' && Math.abs(Number(row.difference || 0)) > 0.01)
            );
            if (!needsAction) return;
            unresolved++;
            outstanding += Number(row.difference || 0);
        });
        s.dolibarr_outstanding = money(outstanding);
        s.unresolved_rows = unresolved;
        s.workflow_reconciled = unresolved === 0 && Math.abs(s.dolibarr_outstanding) <= 0.01;
        s.ebay_minus_dolibarr_documents = s.dolibarr_outstanding;

        if (s.workflow_reconciled) {
            s.dolibarr_outstanding = 0;
            s.ebay_minus_dolibarr_documents = 0;
        }

        if (report.orders.length) {
            s.dolibarr_gross_transactions = money(report.orders.reduce(function (sum, row) {
                return sum + (Number(row.dolibarr_net || 0) > 0 ? Number(row.dolibarr_net) : 0);
            }, 0));
            s.dolibarr_adjustments = money(report.orders.reduce(function (sum, row) {
                return sum + (Number(row.dolibarr_net || 0) < 0 ? -Number(row.dolibarr_net) : 0);
            }, 0));
            s.dolibarr_document_net = money(report.orders.reduce(function (sum, row) {
                return sum + Number(row.dolibarr_net || 0);
            }, 0));
            s.raw_dolibarr_document_net = s.dolibarr_document_net;
        } else if (s.ebay_net_payout !== undefined && s.ebay_net_payout !== null) {
            s.dolibarr_document_net = money(Number(s.ebay_net_payout || 0) - Number(s.dolibarr_outstanding || 0));
            s.raw_dolibarr_document_net = s.dolibarr_document_net;
        }
        // This legacy raw diagnostic was frequently stale after approval and was
        // mistaken for the reconciliation result. dolibarr_outstanding is the one
        // authoritative difference used by the UI, CSV, and JSON.
        delete s.audit_document_difference;

        report.column_totals = computeColumnTotals(report.orders, report.documents);
        delete report.difference_breakdown;
        s.paid_all = !!s.workflow_reconciled && !report.documents.some(function (doc) {
            return doc.document_type === 'invoice' && !doc.is_paid && Math.abs(Number(doc.remain_to_pay || 0)) > 0.01;
        });
        if (s.documents_reconciled === undefined) s.documents_reconciled = !!s.workflow_reconciled;
        if (s.duplicate_invoices_ignored === undefined) s.duplicate_invoices_ignored = 0;
        if (!Array.isArray(s.duplicate_invoice_refs)) s.duplicate_invoice_refs = [];
        return report;
    }

    function toCsv(report) {
        report = normalize(report);
        var lines = [
            csvRow(['RECONCILIATION SUMMARY', 'VALUE']),
            csvRow(['Source file', report.metadata.source_file]),
            csvRow(['Payout ID', report.metadata.payout_id]),
            csvRow(['Payout date', report.metadata.payout_date]),
            csvRow(['Payout method', report.metadata.payout_method]),
            '',
            // Payout summary — labels MUST match the on-screen summary exactly
            // (Gross sales / eBay debits (+) / eBay credits (-) / eBay calculated net /
            //  eBay statement payout / Dolibarr outstanding) so the CSV and the UI read
            // identically. Do not rename one without the other.
            csvRow(['Gross sales', report.summary.ebay_gross_sales]),
            csvRow(['eBay debits (+)', report.summary.ebay_debits]),
            csvRow(['eBay credits (-)', report.summary.ebay_credits]),
            csvRow(['eBay calculated net', report.summary.ebay_net_payout]),
            csvRow(['eBay statement payout', (report.summary.ebay_stated_payout !== null && report.summary.ebay_stated_payout !== undefined)
                ? report.summary.ebay_stated_payout : report.summary.ebay_net_payout]),
            csvRow(['Dolibarr outstanding', report.summary.dolibarr_outstanding]),
            '',
            csvRow(['Unresolved rows', report.summary.unresolved_rows]),
            csvRow(['Reconciled', report.summary.workflow_reconciled ? 'YES' : 'NO']),
            csvRow(['Paid all', report.summary.paid_all ? 'YES' : 'NO']),
            csvRow(['Duplicate unpaid invoices ignored', report.summary.duplicate_invoices_ignored
                + (report.summary.duplicate_invoice_refs.length
                    ? ' (' + report.summary.duplicate_invoice_refs.join(', ') + ')' : '')]),
            '',
            // Supplementary reconciliation totals. Labels here are plain
            // text — no leading '=' (Excel read that as a formula and showed #NAME?).
            csvRow(['DOLIBARR RECONCILIATION TOTALS', '']),
            csvRow(['Dolibarr invoices (+)', report.summary.dolibarr_gross_transactions]),
            csvRow(['Dolibarr credits (-)', money(-report.summary.dolibarr_adjustments)]),
            csvRow(['Dolibarr net', report.summary.dolibarr_document_net]),
            csvRow(['Difference (eBay net - Dolibarr net)', report.summary.dolibarr_outstanding]),
            '',
            csvRow([
                'record_type', 'status', 'order_number', 'ebay_type', 'ebay_net',
                'dolibarr_net', 'difference', 'resolution', 'dolibarr_order_ref', 'dolibarr_order_id',
                'document_id', 'document_ref', 'document_type', 'document_amount',
                'dolibarr_gross_transaction', 'dolibarr_adjustment', 'remain_to_pay',
                'paid', 'notes'
            ])
        ];

        report.orders.forEach(function (row) {
            lines.push(csvRow([
                'ORDER', row.status, row.order_number, row.ebay_type, row.ebay_net,
                row.dolibarr_net, row.difference, row.resolution, row.dolibarr_order_ref, row.dolibarr_order_id,
                '', '', '', '', '', '', '', '', row.notes
            ]));
        });
        report.documents.forEach(function (doc) {
            lines.push(csvRow([
                'DOCUMENT', doc.status, doc.order_number, '', '', '', '', '',
                doc.dolibarr_order_ref, '', doc.document_id, doc.document_ref,
                doc.document_type, doc.document_amount, doc.dolibarr_gross_transaction,
                doc.dolibarr_adjustment, doc.remain_to_pay, paidStatus(doc), doc.notes || ''
            ]));
        });

        // Informational rows for the stray duplicate invoices we collapsed out of the
        // document totals - so the exact refs are visible in the row data, not just
        // the summary. These do NOT affect any total.
        (report.duplicates || []).forEach(function (doc) {
            lines.push(csvRow([
                'DUPLICATE', doc.status, doc.order_number, '', '', '', '', '',
                doc.dolibarr_order_ref, '', doc.document_id, doc.document_ref,
                doc.document_type, doc.document_amount, '', '', doc.remain_to_pay,
                'IGNORED', 'Duplicate of an already-paid invoice; excluded from totals'
            ]));
        });

        // Column totals \u2014 sums each currency column so the figures are visible without
        // hand-summing in a spreadsheet. ebay_net / dolibarr_net / difference total the
        // ORDER rows; the document columns total the DOCUMENT rows. (ebay_net vs
        // dolibarr_net may differ by the still-outstanding amount \u2014 that gap is the
        // point of the difference column.)
        var ct = report.column_totals || computeColumnTotals(report.orders, report.documents);
        lines.push(csvRow([
            'TOTALS', '', '', '', ct.ebay_net, ct.dolibarr_net, ct.difference, '', '', '',
            '', '', '', ct.document_amount, ct.dolibarr_gross_transaction, ct.dolibarr_adjustment,
            ct.remain_to_pay, report.summary.paid_all ? 'YES' : 'NO', ''
        ]));

        return '\uFEFF' + lines.join('\r\n');
    }

    root.EBR_EXPORT = { build: build, normalize: normalize, toCsv: toCsv };
})(typeof window !== 'undefined' ? window : globalThis);
