-- eBay Reconciliation — migration to 1.0.11 (draft + List Reconciliations).
-- Adds draft support to an EXISTING llx_ebayreconcile_payout table.
-- Target: MySQL 8 (RDS). Run once. NOTE: MySQL 8 has no "ADD COLUMN IF NOT EXISTS"
-- (that is MariaDB syntax), so only run the lines for columns not already present.
--
-- Check first:
--   SELECT COLUMN_NAME FROM information_schema.COLUMNS
--    WHERE TABLE_NAME='llx_ebayreconcile_payout' AND COLUMN_NAME IN ('status','state_json');
--
ALTER TABLE llx_ebayreconcile_payout ADD COLUMN status VARCHAR(16) NOT NULL DEFAULT 'settled' AFTER entity;
ALTER TABLE llx_ebayreconcile_payout ADD COLUMN state_json LONGTEXT NULL AFTER summary_json;
ALTER TABLE llx_ebayreconcile_payout MODIFY COLUMN settled_at DATETIME NULL;
-- The new column DEFAULT already marks existing rows 'settled'; belt-and-braces:
UPDATE llx_ebayreconcile_payout SET status = 'settled' WHERE status IS NULL OR status = '';
