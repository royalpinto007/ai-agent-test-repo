-- eBay Reconciliation — reconciliation table.
-- One row per reconciliation: a 'draft' while in progress (resumable) and
-- 'settled' once "Pay all" has run. Both are shown on the List Reconciliations
-- screen as summary totals.
CREATE TABLE llx_ebayreconcile_payout (
    rowid               INTEGER AUTO_INCREMENT PRIMARY KEY,
    entity              INTEGER         NOT NULL DEFAULT 1,
    status              VARCHAR(16)     NOT NULL DEFAULT 'settled',  -- 'draft' | 'settled'
    payout_id           VARCHAR(64)     NOT NULL,
    payout_date         DATE            NULL,
    payout_method       VARCHAR(255)    NULL,
    csv_filename        VARCHAR(255)    NULL,
    orders_count        INTEGER         NOT NULL DEFAULT 0,
    payments_count      INTEGER         NOT NULL DEFAULT 0,
    total_paid          DOUBLE(24,8)    NOT NULL DEFAULT 0,
    settled_at          DATETIME        NULL,           -- NULL while draft
    settled_by          INTEGER         NULL,           -- fk to llx_user.rowid (last editor for drafts)
    summary_json        LONGTEXT        NULL,           -- tie-out totals + per-order payment list for the detail/summary view
    state_json          LONGTEXT        NULL,           -- full reconciliation state (rows + resolutions + notes) so a draft can be resumed
    date_creation       DATETIME        NOT NULL,
    tms                 TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=innodb DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Migration for existing installs (safe to run repeatedly on MySQL 8 / MariaDB 10.5+):
-- ALTER TABLE llx_ebayreconcile_payout ADD COLUMN IF NOT EXISTS status VARCHAR(16) NOT NULL DEFAULT 'settled';
-- ALTER TABLE llx_ebayreconcile_payout ADD COLUMN IF NOT EXISTS state_json LONGTEXT NULL;
-- ALTER TABLE llx_ebayreconcile_payout MODIFY COLUMN settled_at DATETIME NULL;
