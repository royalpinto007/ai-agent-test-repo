<?php
/**
 * Payouts history page — reads from llx_ebayreconcile_payout.
 */
$res = 0;
if (!$res && file_exists("../main.inc.php"))       $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php"))    $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

global $langs, $user, $db;
$langs->loadLangs(array('ebayreconcile@ebayreconcile', 'main'));

if (empty($user->rights->ebayreconcile->use)) accessforbidden();

$targetPayoutId = GETPOST('payout_id', 'alphanohtml');

llxHeader('', $langs->trans("HistoryPageTitle"), '');
$ebrCssV = (int) @filemtime(dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 0));
print '<link rel="stylesheet" href="'.dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 1).'?v='.$ebrCssV.'" />';
// Reuse the same export module the reconcile page uses, so a saved report
// re-downloads to the identical CSV.
$ebrExportJsV = (int) @filemtime(dol_buildpath('/ebayreconcile/js/ebayreconcile-export.js', 0));
print '<script src="'.dol_buildpath('/ebayreconcile/js/ebayreconcile-export.js', 1).'?v='.$ebrExportJsV.'"></script>';
print load_fiche_titre($langs->trans("HistoryPageTitle"), '', 'bank_account');

$sql = "SELECT rowid, payout_id, payout_date, payout_method, csv_filename, orders_count, payments_count, total_paid, settled_at, settled_by, summary_json, state_json";
$sql .= " FROM ".MAIN_DB_PREFIX."ebayreconcile_payout";
$sql .= " WHERE entity IN (".getEntity('facture').")";
$sql .= " ORDER BY settled_at DESC";
$rs = $db->query($sql);

print '<div class="fichecenter ebr-card">';
print '<div class="ebr-titrebar"><i class="fa fa-history"></i> '.$langs->trans("PayoutsHistory").'</div>';
print '<div class="ebr-body">';

if (!$rs || $db->num_rows($rs) === 0) {
    print '<div class="ebr-empty">No payouts settled yet. Reconcile a payout and click <strong>Pay all</strong> — it will show up here.</div>';
} else {
    print '<table class="liste ebr-table ebr-history-table">';
    // Explicit column widths so the table doesn't sprawl into empty
    // whitespace and numeric cells stay visually next to their headers.
    print '<colgroup>';
    print '<col style="width:150px"/>'; // Payout ID
    print '<col style="width:110px"/>'; // Payout date
    print '<col style="width:150px"/>'; // Method
    print '<col style="width:70px"/>';  // Orders
    print '<col style="width:80px"/>';  // Payments
    print '<col style="width:110px"/>'; // Debits
    print '<col style="width:110px"/>'; // Credits
    print '<col style="width:120px"/>'; // Net payout
    print '<col style="width:110px"/>'; // Total paid
    print '<col style="width:150px"/>'; // Settled at
    print '<col style="width:130px"/>'; // By
    print '<col style="width:70px"/>';  // details link
    print '</colgroup>';
    print '<thead><tr class="liste_titre">';
    print '<th>Payout ID</th><th>Payout date</th><th>Method</th>';
    print '<th class="num">Orders</th><th class="num">Payments</th>';
    print '<th class="num">Debits</th><th class="num">Credits</th><th class="num">Net payout</th>';
    print '<th class="num">Total paid</th>';
    print '<th>Settled at</th><th>By</th><th></th>';
    print '</tr></thead><tbody>';

    $idx = 0;
    $reports = array();   // idx => full report JSON, for re-downloading the CSV
    while ($r = $db->fetch_object($rs)) {
        // summary_json is either the legacy items array, or the newer
        // {items:[...], totals:{...}} object. Handle both.
        $decoded = json_decode($r->summary_json, true);
        $totals = array();
        $report = null;
        if (is_array($decoded) && isset($decoded['items'])) {
            $items  = is_array($decoded['items']) ? $decoded['items'] : array();
            $totals = isset($decoded['totals']) && is_array($decoded['totals']) ? $decoded['totals'] : array();
            $report = (isset($decoded['report']) && is_array($decoded['report'])) ? $decoded['report'] : null;
        } else {
            $items = is_array($decoded) ? $decoded : array();
        }
        $soByOrder = array();
        if ($report && !empty($report['orders']) && is_array($report['orders'])) {
            foreach ($report['orders'] as $row) {
                $ord = isset($row['order_number']) ? (string) $row['order_number'] : '';
                if ($ord === '') continue;
                $soByOrder[$ord] = array(
                    'ref' => isset($row['dolibarr_order_ref']) ? $row['dolibarr_order_ref'] : '',
                    'id'  => isset($row['dolibarr_order_id']) ? $row['dolibarr_order_id'] : '',
                );
            }
        }
        if (!empty($r->state_json)) {
            $state = json_decode($r->state_json, true);
            if (is_array($state) && !empty($state['results']) && is_array($state['results'])) {
                foreach ($state['results'] as $row) {
                    $ord = isset($row['order_number']) ? (string) $row['order_number'] : '';
                    if ($ord === '') continue;
                    if (!isset($soByOrder[$ord])) $soByOrder[$ord] = array('ref' => '', 'id' => '');
                    if (empty($soByOrder[$ord]['ref']) && !empty($row['dolibarr_order_ref'])) $soByOrder[$ord]['ref'] = $row['dolibarr_order_ref'];
                    if (empty($soByOrder[$ord]['id']) && !empty($row['dolibarr_order_id'])) $soByOrder[$ord]['id'] = $row['dolibarr_order_id'];
                }
            }
        }
        if ($report !== null) $reports[$idx] = $report;
        $fmtTot = function ($key) use ($totals) {
            return (isset($totals[$key]) && $totals[$key] !== null) ? price((float)$totals[$key]) : '<span class="ebr-sub">-</span>';
        };

        // Resolve settled_by username
        $byName = '-';
        if ($r->settled_by) {
            $u = new User($db);
            if ($u->fetch((int)$r->settled_by) > 0) $byName = $u->getFullName($langs);
        }

        print '<tr class="'.($idx % 2 === 0 ? 'pair' : 'impair').'" data-payout-id="'.dol_escape_htmltag($r->payout_id).'">';
        print '<td><code>'.dol_escape_htmltag($r->payout_id).'</code></td>';
        print '<td>'.($r->payout_date ? dol_print_date($db->jdate($r->payout_date), 'day') : '-').'</td>';
        print '<td><span class="ebr-sub">'.dol_escape_htmltag($r->payout_method ?: '-').'</span></td>';
        print '<td class="num">'.(int)$r->orders_count.'</td>';
        print '<td class="num">'.(int)$r->payments_count.'</td>';
        print '<td class="num ebr-diff-pos">'.$fmtTot('totalDebits').'</td>';
        print '<td class="num ebr-diff-neg">'.$fmtTot('totalCredits').'</td>';
        print '<td class="num"><strong>'.$fmtTot('netPayout').'</strong></td>';
        print '<td class="num"><strong>'.price((float)$r->total_paid).'</strong></td>';
        print '<td><span class="ebr-sub">'.dol_print_date($db->jdate($r->settled_at), 'dayhour').'</span></td>';
        print '<td><span class="ebr-sub">'.dol_escape_htmltag($byName).'</span></td>';
        print '<td><a class="ebr-toggle" data-detail="'.$idx.'" href="javascript:;">details ▾</a>';
        if ($report !== null) {
            print ' &middot; <a class="ebr-csv-dl" data-csv="'.$idx.'" href="javascript:;" title="Re-download the reconciliation CSV">CSV</a>';
            print ' &middot; <a class="ebr-json-dl" data-json="'.$idx.'" href="javascript:;" title="Re-download the reconciliation JSON">JSON</a>';
        }
        print '</td>';
        print '</tr>';

        // Detail row (hidden by default).
        // The <td colspan> is styled with `padding: 0` via .ebr-detail > td so
        // the inner table flows under the explicit padding from .ebr-detail-inner.
        print '<tr class="ebr-detail" data-detail="'.$idx.'" hidden><td colspan="12"><div class="ebr-detail-inner">';
        if (empty($items)) {
            print '<em>No per-payment data recorded for this entry.</em>';
        } else {
            print '<table class="ebr-history-detail-table">';
            print '<colgroup>';
            print '<col style="width:170px"/>'; // Order number
            print '<col style="width:140px"/>'; // SO ref
            print '<col style="width:180px"/>'; // Invoice
            print '<col style="width:100px"/>'; // Amount
            print '<col style="width:110px"/>'; // Payment ID
            print '</colgroup>';
            print '<thead><tr>';
            print '<th>Order number</th>';
            print '<th>SO ref</th>';
            print '<th>Invoice</th>';
            print '<th class="num">Amount</th>';
            print '<th>Payment ID</th>';
            print '</tr></thead><tbody>';
            foreach ($items as $it) {
                $orderNumber = isset($it['orderNumber']) ? (string) $it['orderNumber'] : '';
                $fallbackSo = ($orderNumber !== '' && isset($soByOrder[$orderNumber])) ? $soByOrder[$orderNumber] : array();
                $soRef = !empty($it['soRef']) ? $it['soRef'] : (!empty($fallbackSo['ref']) ? $fallbackSo['ref'] : '-');
                $soId = !empty($it['soId']) ? $it['soId'] : (!empty($fallbackSo['id']) ? $fallbackSo['id'] : 0);
                $soUrl = !empty($soId) ? DOL_URL_ROOT.'/commande/card.php?id='.(int)$soId : null;
                $invRef = $it['invoiceRef'] ?? '-';
                $invUrl = !empty($it['invoiceId']) ? DOL_URL_ROOT.'/compta/facture/card.php?id='.(int)$it['invoiceId'] : null;
                $payId = $it['paymentId'] ?? '';
                $payUrl = !empty($payId) && ctype_digit((string)$payId)
                    ? DOL_URL_ROOT.'/compta/paiement/card.php?id='.(int)$payId
                    : null;
                print '<tr>';
                print '<td>'.dol_escape_htmltag($it['orderNumber'] ?? '-').'</td>';
                print '<td>'.($soUrl ? '<a href="'.$soUrl.'" target="_blank">'.dol_escape_htmltag($soRef).'</a>' : dol_escape_htmltag($soRef)).'</td>';
                print '<td>'.($invUrl ? '<a href="'.$invUrl.'" target="_blank">'.dol_escape_htmltag($invRef).'</a>' : dol_escape_htmltag($invRef)).'</td>';
                print '<td class="num">'.price((float)($it['amount'] ?? 0)).'</td>';
                print '<td>'.($payUrl
                    ? '<a href="'.$payUrl.'" target="_blank"><code>'.dol_escape_htmltag($payId).'</code></a>'
                    : '<code>'.dol_escape_htmltag($payId ?: '-').'</code>').'</td>';
                print '</tr>';
            }
            print '</tbody></table>';
        }
        print '</div></td></tr>';
        $idx++;
    }
    print '</tbody></table>';

    print '<div class="ebr-modal-bg" id="ebrHistoryMessageModal">';
    print '<div class="ebr-modal" style="width:440px">';
    print '<div class="mhead"><i class="fa fa-info-circle"></i> Export unavailable</div>';
    print '<div class="mbody"><p id="ebrHistoryMessage" style="margin:0"></p></div>';
    print '<div class="mfoot"><button class="butAction" id="ebrHistoryMessageClose" type="button">'.$langs->trans("Close").'</button></div>';
    print '</div></div>';

    print '<script>window.EBR_REPORTS = '.json_encode($reports).'; window.EBR_HISTORY_TARGET = '.json_encode($targetPayoutId).';</script>';
    print '<script>
    const historyMessageModal = document.getElementById("ebrHistoryMessageModal");
    function showHistoryMessage(message) {
        document.getElementById("ebrHistoryMessage").textContent = message;
        historyMessageModal.classList.add("open");
        document.getElementById("ebrHistoryMessageClose").focus();
    }
    document.getElementById("ebrHistoryMessageClose").addEventListener("click", () => historyMessageModal.classList.remove("open"));
    document.querySelectorAll("a.ebr-toggle").forEach(a => {
        a.addEventListener("click", e => {
            const idx = a.dataset.detail;
            const row = document.querySelector("tr.ebr-detail[data-detail=\""+idx+"\"]");
            if (row) row.hidden = !row.hidden;
        });
    });
    if (window.EBR_HISTORY_TARGET) {
        let main = null;
        document.querySelectorAll("tr[data-payout-id]").forEach(row => {
            if (!main && row.dataset.payoutId === window.EBR_HISTORY_TARGET) main = row;
        });
        if (main) {
            const toggle = main.querySelector("a.ebr-toggle");
            const idx = toggle ? toggle.dataset.detail : null;
            const detail = idx !== null ? document.querySelector("tr.ebr-detail[data-detail=\"" + idx + "\"]") : null;
            if (detail) detail.hidden = false;
            main.classList.add("ebr-history-target");
            main.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    }
    // Re-download the saved reconciliation CSV (regenerated from the stored report
    // via the same export module used on the reconcile page).
    document.querySelectorAll("a.ebr-csv-dl").forEach(a => {
        a.addEventListener("click", e => {
            const rep = (window.EBR_REPORTS || {})[a.dataset.csv];
            if (!rep || !window.EBR_EXPORT) { showHistoryMessage("No saved report for this payout."); return; }
            const csv = window.EBR_EXPORT.toCsv(rep);
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            const dl = document.createElement("a");
            const pid = (rep.metadata && rep.metadata.payout_id) ? rep.metadata.payout_id : "payout";
            dl.href = url; dl.download = pid + "-reconcile-report.csv";
            dl.click(); URL.revokeObjectURL(url);
        });
    });
    document.querySelectorAll("a.ebr-json-dl").forEach(a => {
        a.addEventListener("click", e => {
            const rep = (window.EBR_REPORTS || {})[a.dataset.json];
            if (!rep || !window.EBR_EXPORT) { showHistoryMessage("No saved report for this payout."); return; }
            const normalized = window.EBR_EXPORT.normalize ? window.EBR_EXPORT.normalize(rep) : rep;
            const blob = new Blob([JSON.stringify(normalized, null, 2)], { type: "application/json;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            const dl = document.createElement("a");
            const pid = (normalized.metadata && normalized.metadata.payout_id) ? normalized.metadata.payout_id : "payout";
            dl.href = url; dl.download = pid + "-reconcile-report.json";
            dl.click(); URL.revokeObjectURL(url);
        });
    });
    </script>';
}
print '</div></div>';

llxFooter();
$db->close();
