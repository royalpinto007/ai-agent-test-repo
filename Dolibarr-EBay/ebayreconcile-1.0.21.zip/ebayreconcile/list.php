<?php
/**
 * List Reconciliations — every reconciliation (draft + settled) shown as summary
 * totals (not per-line detail), so you can see how the math worked at a glance.
 * Drafts can be resumed; settled rows link to the payout history detail.
 */
$res = 0;
if (!$res && file_exists("../main.inc.php"))       $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php"))    $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

global $langs, $user, $db;
$langs->loadLangs(array('ebayreconcile@ebayreconcile', 'main'));

if (empty($user->rights->ebayreconcile->use)) accessforbidden();

llxHeader('', $langs->trans("ListPageTitle"), '');
$ebrCssV = (int) @filemtime(dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 0));
print '<link rel="stylesheet" href="'.dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 1).'?v='.$ebrCssV.'" />';
print load_fiche_titre($langs->trans("ListPageTitle"), '', 'bank_account');

$sql  = "SELECT rowid, status, payout_id, payout_date, payout_method, csv_filename,";
$sql .= " orders_count, payments_count, total_paid, settled_at, settled_by, summary_json, date_creation, tms";
$sql .= " FROM ".MAIN_DB_PREFIX."ebayreconcile_payout";
$sql .= " WHERE entity IN (".getEntity('facture').")";
// Drafts first (most actionable), then most-recent activity.
$sql .= " ORDER BY (status = 'draft') DESC, tms DESC";
$rs = $db->query($sql);

$reconcileUrl = dol_buildpath('/ebayreconcile/reconcile.php', 1);
$historyUrl   = dol_buildpath('/ebayreconcile/history.php', 1);
$actionUrl    = dol_buildpath('/ebayreconcile/action.php', 1);
$canWrite     = !empty($user->rights->ebayreconcile->write);

print '<div class="fichecenter ebr-card">';
print '<div class="ebr-titrebar"><i class="fa fa-list"></i> '.$langs->trans("ListReconciliations").'</div>';
print '<div class="ebr-body">';

if (!$rs || $db->num_rows($rs) === 0) {
    print '<div class="ebr-empty">'.$langs->trans("NoReconciliationsYet").' <a href="'.$reconcileUrl.'">'.$langs->trans("ReconcileAPayout").'</a>.</div>';
} else {
    print '<table class="liste ebr-table ebr-list-table">';
    print '<colgroup>';
    print '<col style="width:90px"/>';   // status
    print '<col/>';                       // file
    print '<col style="width:140px"/>';  // payout id
    print '<col style="width:100px"/>';  // payout date
    print '<col style="width:60px"/>';   // orders
    print '<col style="width:110px"/>';  // gross
    print '<col style="width:110px"/>';  // debits
    print '<col style="width:110px"/>';  // credits
    print '<col style="width:120px"/>';  // net
    print '<col style="width:120px"/>';  // ebay payout
    print '<col style="width:100px"/>';  // diff
    print '<col style="width:160px"/>';  // updated/settled
    print '<col style="width:150px"/>';  // actions
    print '</colgroup>';
    print '<thead><tr class="liste_titre">';
    print '<th>'.$langs->trans("Status").'</th>';
    print '<th>'.$langs->trans("File").'</th>';
    print '<th>Payout ID</th><th>Payout date</th>';
    print '<th class="num">Orders</th>';
    print '<th class="num">'.$langs->trans("ColGrossSales").'</th>';
    print '<th class="num">Debits</th><th class="num">Credits</th>';
    print '<th class="num">'.$langs->trans("DolibarrNet").'</th>';
    print '<th class="num">'.$langs->trans("EbayPayoutAmount").'</th>';
    print '<th class="num">'.$langs->trans("ColDiff").'</th>';
    print '<th>'.$langs->trans("LastActivity").'</th>';
    print '<th></th>';
    print '</tr></thead><tbody>';

    $idx = 0;
    while ($r = $db->fetch_object($rs)) {
        $decoded = json_decode($r->summary_json, true);
        $totals  = (is_array($decoded) && isset($decoded['totals']) && is_array($decoded['totals'])) ? $decoded['totals'] : array();
        $report  = (is_array($decoded) && isset($decoded['report']) && is_array($decoded['report'])) ? $decoded['report'] : array();
        $reportSummary = (isset($report['summary']) && is_array($report['summary'])) ? $report['summary'] : array();

        // Totals are stored under slightly different keys for drafts (live tie-out)
        // and settled rows (pay-all snapshot); read either.
        $pick = function (array $keys) use ($totals, $reportSummary) {
            foreach ($keys as $k) {
                if (isset($totals[$k]) && $totals[$k] !== null && $totals[$k] !== '') return (float) $totals[$k];
            }
            foreach ($keys as $k) {
                if (isset($reportSummary[$k]) && $reportSummary[$k] !== null && $reportSummary[$k] !== '') return (float) $reportSummary[$k];
            }
            return null;
        };
        $fmt = function ($v, $cls = '') {
            if ($v === null) return '<span class="ebr-sub">-</span>';
            return ($cls ? '<span class="'.$cls.'">' : '').price($v).($cls ? '</span>' : '');
        };

        $gross   = $pick(array('grossSales'));
        $debits  = $pick(array('debits', 'totalDebits'));
        $credits = $pick(array('credits', 'totalCredits'));
        $net     = $pick(array('dolibarrNet', 'netPayout'));
        $payout  = $pick(array('ebayPayout', 'statedPayout', 'ebay_stated_payout', 'ebay_net_payout', 'netPayout'));
        $isDraft = ($r->status === 'draft');
        // A settled payout has completed every reconciliation action. Older saved
        // reports may retain the pre-resolution outstanding value, so never show
        // that stale diagnostic as the final settled difference.
        $diff = $isDraft
            ? $pick(array('diff', 'dolibarr_outstanding', 'ebay_minus_dolibarr_documents', 'tieDiff'))
            : 0.0;

        // Resolve user name (last editor for drafts / settler for settled).
        $byName = '-';
        if ($r->settled_by) {
            $u = new User($db);
            if ($u->fetch((int)$r->settled_by) > 0) $byName = $u->getFullName($langs);
        }
        $whenRaw = $isDraft ? $r->tms : $r->settled_at;
        $when = $whenRaw ? dol_print_date($db->jdate($whenRaw), 'dayhour') : '-';

        print '<tr class="'.($idx % 2 === 0 ? 'pair' : 'impair').'">';
        if ($isDraft) {
            print '<td><span class="ebr-badge ebr-badge-draft">'.$langs->trans("StatusDraft").'</span></td>';
        } else {
            print '<td><span class="ebr-badge ebr-badge-settled">'.$langs->trans("StatusSettled").'</span></td>';
        }
        print '<td>'.dol_escape_htmltag($r->csv_filename ?: '-').'</td>';
        print '<td><code>'.dol_escape_htmltag($r->payout_id).'</code></td>';
        print '<td>'.($r->payout_date ? dol_print_date($db->jdate($r->payout_date), 'day') : '-').'</td>';
        print '<td class="num">'.(int)$r->orders_count.'</td>';
        print '<td class="num">'.$fmt($gross).'</td>';
        print '<td class="num">'.$fmt($debits, 'ebr-diff-pos').'</td>';
        print '<td class="num">'.$fmt($credits, 'ebr-diff-neg').'</td>';
        print '<td class="num"><strong>'.$fmt($net).'</strong></td>';
        print '<td class="num">'.$fmt($payout).'</td>';
        // Diff: highlight non-zero (still unreconciled) for drafts.
        $diffcls = ($diff !== null && abs($diff) >= 0.005) ? 'ebr-diff-neg' : '';
        print '<td class="num">'.$fmt($diff, $diffcls).'</td>';
        print '<td><span class="ebr-sub">'.$when.($byName !== '-' ? ' · '.dol_escape_htmltag($byName) : '').'</span></td>';
        print '<td class="ebr-list-actions">';
        if ($isDraft) {
            print '<a class="button button-small" href="'.$reconcileUrl.'?draft='.(int)$r->rowid.'">'.$langs->trans("Continue").'</a>';
            if ($canWrite) {
                print ' <a class="button button-small button-cancel ebr-draft-del" href="javascript:;" data-id="'.(int)$r->rowid.'">'.$langs->trans("Delete").'</a>';
            }
        } else {
            print '<a class="button button-small" href="'.$historyUrl.'?payout_id='.urlencode($r->payout_id).'">'.$langs->trans("ViewInHistory").'</a>';
        }
        print '</td>';
        print '</tr>';
        $idx++;
    }
    print '</tbody></table>';

    if ($canWrite) {
        print '<div class="ebr-modal-bg" id="ebrDeleteDraftModal">';
        print '<div class="ebr-modal" style="width:460px">';
        print '<div class="mhead"><i class="fa fa-trash"></i> '.$langs->trans("DeleteDraft").'</div>';
        print '<div class="mbody"><p id="ebrDeleteDraftMessage" style="margin:0"></p><div class="ebr-error" id="ebrDeleteDraftError" hidden></div></div>';
        print '<div class="mfoot"><button class="button" id="ebrDeleteDraftCancel" type="button">'.$langs->trans("Cancel").'</button>';
        print '<button class="butActionDelete" id="ebrDeleteDraftConfirm" type="button">'.$langs->trans("Delete").'</button></div>';
        print '</div></div>';
        print '<script>window.EBR_LIST = '.json_encode(array(
            'actionUrl' => $actionUrl,
            'token'     => newToken(),
            'confirmDelete' => $langs->trans("ConfirmDeleteDraft"),
        )).';</script>';
        print '<script>
        var ebrDeleteTarget = null;
        var ebrDeleteModal = document.getElementById("ebrDeleteDraftModal");
        var ebrDeleteError = document.getElementById("ebrDeleteDraftError");
        var ebrDeleteConfirm = document.getElementById("ebrDeleteDraftConfirm");
        document.getElementById("ebrDeleteDraftMessage").textContent = window.EBR_LIST.confirmDelete;
        document.getElementById("ebrDeleteDraftCancel").addEventListener("click", function () {
            ebrDeleteModal.classList.remove("open");
            ebrDeleteTarget = null;
        });
        ebrDeleteConfirm.addEventListener("click", function () {
            if (!ebrDeleteTarget) return;
            var target = ebrDeleteTarget;
            ebrDeleteConfirm.disabled = true;
            ebrDeleteConfirm.textContent = "Deleting...";
            ebrDeleteError.hidden = true;
            fetch(window.EBR_LIST.actionUrl + "?action=delete_draft&token=" + encodeURIComponent(window.EBR_LIST.token), {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: parseInt(target.dataset.id, 10) })
            }).then(function (r) { return r.json(); }).then(function (j) {
                if (!j || !j.ok) throw new Error((j && j.error) || "Delete failed");
                var tr = target.closest("tr");
                if (tr) tr.remove();
                ebrDeleteModal.classList.remove("open");
                ebrDeleteTarget = null;
            }).catch(function (err) {
                ebrDeleteError.textContent = err.message || "Delete failed";
                ebrDeleteError.hidden = false;
            }).then(function () {
                ebrDeleteConfirm.disabled = false;
                ebrDeleteConfirm.textContent = "Delete";
            });
        });
        document.querySelectorAll("a.ebr-draft-del").forEach(function (a) {
            a.addEventListener("click", function () {
                ebrDeleteTarget = a;
                ebrDeleteError.hidden = true;
                ebrDeleteModal.classList.add("open");
                ebrDeleteConfirm.focus();
            });
        });
        </script>';
    }
}
print '</div></div>';

llxFooter();
$db->close();
