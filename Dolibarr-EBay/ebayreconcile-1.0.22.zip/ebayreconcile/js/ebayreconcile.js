/* eBay Reconciliation — frontend JS
   Bootstrapped from window.EBR_BOOT (set inline by reconcile.php).
   Handles: filter chips, search, sort, per-row Approve/Create-invoice,
   bulk Approve, bulk Pay, and saves payout summary on Pay all success. */

(function () {
    function uploadT(key, fallback) {
        var dict = window.EBR_UPLOAD_I18N || {};
        return dict[key] || fallback;
    }

    function initUploadUi() {
        var input = document.querySelector('#ebrUploadForm input[type="file"][name="payoutcsv"]');
        var label = document.getElementById('ebrSelectedFile');
        initUploadCustomerSearch();
        if (!input || !label) return;

        function showSelected() {
            var file = input.files && input.files[0];
            label.textContent = file
                ? uploadT('SelectedFile', 'Selected file:') + ' ' + file.name
                : uploadT('NoFileSelected', 'No file selected yet.');
            var customerBlock = document.getElementById('ebrUploadDefaultCustomerBlock');
            if (customerBlock) customerBlock.hidden = !file;
        }
        input.addEventListener('change', showSelected);

        // Drag-and-drop onto the dropzone. The markup advertises "Drop or
        // Browse", but without these handlers a dropped file just makes the
        // browser navigate to it. Wire drop -> populate the file input.
        var zone = (input.closest && input.closest('.ebr-dropzone'))
            || document.querySelector('#ebrUploadForm .ebr-dropzone');
        if (!zone) return;

        function squelch(e) { e.preventDefault(); e.stopPropagation(); }
        ['dragenter', 'dragover'].forEach(function (ev) {
            zone.addEventListener(ev, function (e) { squelch(e); zone.classList.add('ebr-dragover'); });
        });
        ['dragleave', 'dragend'].forEach(function (ev) {
            zone.addEventListener(ev, function (e) { squelch(e); zone.classList.remove('ebr-dragover'); });
        });
        zone.addEventListener('drop', function (e) {
            squelch(e);
            zone.classList.remove('ebr-dragover');
            var files = e.dataTransfer && e.dataTransfer.files;
            if (!files || !files.length) return;
            var file = files[0];
            // Accept only CSV, matching the input's accept attribute.
            var okName = /\.csv$/i.test(file.name);
            var okType = !file.type || /csv|excel|text\/plain/i.test(file.type);
            if (!okName && !okType) {
                label.textContent = uploadT('InvalidFileType', 'Please drop a .csv payout file.');
                return;
            }
            // Programmatically assign the dropped file to the <input> so the
            // normal form submit carries it. Needs DataTransfer (modern browsers).
            try {
                var dt = new DataTransfer();
                dt.items.add(file);
                input.files = dt.files;
            } catch (err) {
                label.textContent = uploadT('DragDropUnsupported', 'Drag-and-drop is not supported in this browser — click to browse instead.');
                return;
            }
            showSelected();
        });
    }

    function customerOptionHtml(c) {
        var selected = !!c.selected;
        return '<button type="button" class="ebr-customer-option' + (selected ? ' is-selected' : '') + '" data-id="' + esc(c.id) + '" data-label="' + esc(c.label || '') + '" data-name="' + esc(c.name || '') + '"' + (selected ? ' disabled aria-disabled="true"' : '') + '>'
                + '<strong>' + esc(c.name || c.label || ('Customer #' + c.id)) + '</strong>'
                + '<span>#' + esc(c.id) + (c.code_client ? ' - ' + esc(c.code_client) : '') + (c.email ? ' - ' + esc(c.email) : '') + (selected ? ' - Already selected' : '') + '</span>'
                + '</button>';
    }

    function renderCustomerResultList(resultsEl, customers) {
        if (!resultsEl) return;
        if (!customers || !customers.length) {
            resultsEl.innerHTML = '<div class="ebr-customer-empty">No matching customers found.</div>';
            return;
        }
        resultsEl.innerHTML = customers.map(customerOptionHtml).join('');
    }

    function bindCustomerPickerClose(picker, box) {
        if (!picker || !box) return;
        document.addEventListener('click', function (e) {
            if (box.hidden) return;
            if (picker.contains(e.target)) return;
            box.hidden = true;
        });
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape' || box.hidden) return;
            box.hidden = true;
        });
    }

    function initUploadCustomerSearch() {
        var dict = window.EBR_UPLOAD_I18N || {};
        var changeBtn = document.getElementById('ebrUploadChangeDefaultCustomer');
        var box = document.getElementById('ebrUploadCustomerSearch');
        var picker = changeBtn ? changeBtn.closest('.ebr-customer-picker') : null;
        var searchInput = document.getElementById('ebrUploadCustomerSearchInput');
        var results = document.getElementById('ebrUploadCustomerResults');
        var hidden = document.getElementById('ebrUploadDefaultSocid');
        var setupDefault = document.getElementById('ebrUploadSetupDefaultSocid');
        var label = document.getElementById('ebrUploadDefaultCustomerLabel');
        var title = document.getElementById('ebrUploadDefaultCustomerTitle');
        var actionUrl = dict.actionUrl;
        var token = dict.token;
        var timer = null;
        if (!changeBtn || !box || !searchInput || !results || !hidden || !label || !actionUrl) return;

        function search(q) {
            fetch(actionUrl + '?action=search_customer&token=' + encodeURIComponent(token || ''), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'same-origin',
                body: JSON.stringify({ q: q, currentSocid: Number(hidden.value || 0) })
            }).then(function (res) {
                return res.json();
            }).then(function (data) {
                if (!data.ok) throw new Error(data.error || 'Customer search failed');
                renderCustomerResultList(results, data.customers || []);
            }).catch(function (err) {
                results.innerHTML = '<div class="ebr-customer-empty err">' + esc(err.message || 'Search failed') + '</div>';
            });
        }

        changeBtn.addEventListener('click', function () {
            box.hidden = !box.hidden;
            if (!box.hidden) {
                searchInput.value = '';
                renderCustomerResultList(results, []);
                search('');
                searchInput.focus();
            }
        });
        searchInput.addEventListener('input', function () {
            var q = searchInput.value.trim();
            if (timer) clearTimeout(timer);
            if (q.length < 2) {
                renderCustomerResultList(results, []);
                return;
            }
            timer = setTimeout(function () { search(q); }, 250);
        });
        results.addEventListener('click', function (e) {
            var btn = e.target.closest('.ebr-customer-option');
            if (!btn || btn.disabled) return;
            hidden.value = btn.getAttribute('data-id') || '';
            label.textContent = btn.getAttribute('data-label') || btn.textContent || '';
            if (title) {
                title.textContent = Number(hidden.value || 0) === Number(setupDefault && setupDefault.value || 0)
                    ? (dict.DefaultCustomerForUnmatchedDocs || 'Default customer for unmatched payout documents')
                    : (dict.SelectedCustomerForUnmatchedDocs || 'Selected customer for unmatched payout documents');
            }
            box.hidden = true;
        });
        bindCustomerPickerClose(picker, box);
    }

    initUploadUi();
    if (!window.EBR_BOOT) return; // page rendered without results (just upload form)

    var state = {
        results: window.EBR_BOOT.results || [],
        payout: window.EBR_BOOT.payout || null,
        totals: window.EBR_BOOT.totals || null,
        sourceFile: window.EBR_BOOT.sourceFile || null,
        setupDefaultSocid: Number(window.EBR_BOOT.setupDefaultSocid || window.EBR_BOOT.defaultSocid || 0),
        defaultSocid: Number(window.EBR_BOOT.defaultSocid || 0),
        defaultCustomerLabel: window.EBR_BOOT.defaultCustomerLabel || '',
        writePerm: !!window.EBR_BOOT.writePerm,
        alreadySettled: !!window.EBR_BOOT.alreadySettled,
        actionUrl: window.EBR_BOOT.actionUrl,
        listUrl: window.EBR_BOOT.listUrl || null,
        draftId: window.EBR_BOOT.draftId || 0,
        token: window.EBR_BOOT.token,
        invoiceUrlTemplate: window.EBR_BOOT.invoiceUrlTemplate,
        orderUrlTemplate: window.EBR_BOOT.orderUrlTemplate,
        i18n: window.EBR_BOOT.i18n || {},
        filter: "ALL",
        query: "",
        sortKey: null,
        sortDir: 1,
        pending: null,    // approve modal pending
        pendingCreate: null, // create-invoice modal pending
        pendingBulkPay: null,
        activeOperations: 0,
    };
    window.__EBR = state; // for debugging

    function selectedDefaultSocid() {
        var input = document.getElementById('ebrDefaultSocid');
        var val = input ? Number(input.value || 0) : Number(state.defaultSocid || 0);
        state.defaultSocid = isFinite(val) && val > 0 ? Math.floor(val) : 0;
        return state.defaultSocid;
    }

    function selectedDefaultCustomerLabel() {
        var el = document.getElementById('ebrDefaultCustomerLabel');
        return (el && el.textContent ? el.textContent : state.defaultCustomerLabel || '').trim();
    }

    function customerTitleText(socid) {
        return Number(socid || 0) === Number(state.setupDefaultSocid || 0)
            ? t('DefaultCustomerForUnmatchedDocs', 'Default customer for unmatched payout documents')
            : t('SelectedCustomerForUnmatchedDocs', 'Selected customer for unmatched payout documents');
    }

    function setDefaultCustomer(customer) {
        if (!customer || !customer.id) return;
        state.defaultSocid = Number(customer.id);
        state.defaultCustomerLabel = customer.label || ((customer.name || 'Customer') + ' (#' + customer.id + ')');
        var input = document.getElementById('ebrDefaultSocid');
        if (input) input.value = String(state.defaultSocid);
        var label = document.getElementById('ebrDefaultCustomerLabel');
        if (label) label.textContent = state.defaultCustomerLabel;
        var title = document.getElementById('ebrDefaultCustomerTitle');
        if (title) title.textContent = customerTitleText(state.defaultSocid);
        var box = document.getElementById('ebrCustomerSearch');
        if (box) box.hidden = true;
    }

    function renderCustomerResults(customers) {
        var results = document.getElementById('ebrCustomerResults');
        if (!results) return;
        if (!customers || !customers.length) {
            results.innerHTML = '<div class="ebr-customer-empty">No matching customers found.</div>';
            return;
        }
        results.innerHTML = customers.map(function (c) {
            return '<button type="button" class="ebr-customer-option" data-id="' + esc(c.id) + '" data-label="' + esc(c.label || '') + '" data-name="' + esc(c.name || '') + '">'
                + '<strong>' + esc(c.name || c.label || ('Customer #' + c.id)) + '</strong>'
                + '<span>#' + esc(c.id) + (c.code_client ? ' - ' + esc(c.code_client) : '') + (c.email ? ' - ' + esc(c.email) : '') + '</span>'
                + '</button>';
        }).join('');
    }

    function searchCustomers(q) {
        return jpost('search_customer', { q: q, currentSocid: selectedDefaultSocid() }).then(function (data) {
            if (!data.ok) throw new Error(data.error || 'Customer search failed');
            renderCustomerResults(data.customers || []);
        }).catch(function (err) {
            var results = document.getElementById('ebrCustomerResults');
            if (results) results.innerHTML = '<div class="ebr-customer-empty err">' + esc(err.message || 'Search failed') + '</div>';
        });
    }

    function fmt(n) {
        if (n === null || n === undefined || n === "") return "";
        var v = Number(n);
        if (!isFinite(v)) return String(n);
        return v.toFixed(2);
    }
    // File-level tie-out totals. Prefer the server-computed figures (they include
    // the Gross sales column and every line); fall back to summing results.
    function fileTotals() {
        var t = state.totals;
        if (t && t.netPayout !== null && t.netPayout !== undefined) return t;
        var d = 0, c = 0;
        state.results.forEach(function (r) {
            var n = Number(r.ebay_net || 0);
            if (n >= 0) d += n; else c += n;
        });
        return { grossSales: null, debits: Math.round(d * 100) / 100, credits: Math.round(c * 100) / 100, netPayout: Math.round((d + c) * 100) / 100 };
    }
    function soUrl(id)  { return state.orderUrlTemplate.replace("{id}", id); }
    function invUrl(id) { return state.invoiceUrlTemplate.replace("{id}", id); }
    function t(key, fallback) { return state.i18n[key] || fallback; }

    function beginOperation() {
        state.activeOperations++;
        render();
    }

    function endOperation() {
        state.activeOperations = Math.max(0, state.activeOperations - 1);
        render();
    }

    function pickLargestInvoice(r) {
        var invs = (r.invoices || []).filter(function (i) { return i.type === "invoice"; });
        if (invs.length === 0) return null;
        return invs.reduce(function (a, b) {
            return Math.abs(Number(b.total_ht || 0)) > Math.abs(Number(a.total_ht || 0)) ? b : a;
        });
    }

    function diffCell(v) {
        if (v === null || v === undefined || v === "") return "";
        var n = Number(v);
        var cls = n > 0 ? "ebr-diff-pos" : (n < 0 ? "ebr-diff-neg" : "ebr-diff-zero");
        return '<span class="' + cls + '">' + fmt(v) + '</span>';
    }

    function ebayNetCell(r) {
        var main = fmt(r.ebay_net);
        var lines = r.ebay_lines || [];
        // Always show the per-line breakdown with the eBay Type (CSV column B) so
        // the user sees how every line was coded by eBay — including single-line rows.
        if (lines.length === 0) return main;
        var parts = lines.map(function (l) {
            var n = Number(l.net);
            var cls = n > 0 ? "bd-pos" : (n < 0 ? "bd-neg" : "");
            var sign = n > 0 ? "+" : "";
            var lbl = l.type || "row";
            return '<span class="bd-row">' + esc(lbl) + ' <span class="' + cls + '">' + sign + n.toFixed(2) + '</span></span>';
        });
        return main + '<span class="ebr-breakdown">' + parts.join('<span class="bd-sep">·</span>') + '</span>';
    }

    function typeCell(r) {
        var ty = r.ebay_type || (r.ebay_types || []).join(', ');
        if (!ty) return '<span class="ebr-sub">-</span>';
        var cls = /refund/i.test(ty) ? 'ebr-type-refund' : 'ebr-type-other';
        return '<span class="ebr-typebadge ' + cls + '">' + esc(ty) + '</span>';
    }

    // What document the action will create for this row.
    // Sign of the relevant amount determines type: negative → credit note (we owe eBay),
    // positive → invoice (eBay owes us). For MISMATCH/MATCH use the diff; for
    // MISSING/NO_LINKED_INVOICES use the eBay net (no Dolibarr side yet).
    function docTypeForRow(r) {
        if (r.status === 'MISMATCH' || r.status === 'MATCH') {
            return Number(r.diff) < 0 ? 'credit_note' : 'invoice';
        }
        return Number(r.ebay_net) < 0 ? 'credit_note' : 'invoice';
    }
    function docLabel(r) {
        return docTypeForRow(r) === 'credit_note' ? 'Create credit note' : 'Create invoice';
    }

    function invoicesCell(r) {
        if (!r.invoices || r.invoices.length === 0) return '<span class="ebr-sub">-</span>';
        return r.invoices.map(function (i) {
            var label = i.ref || i.id;
            var type = i.type ? ' <span class="ebr-sub">[' + esc(i.type) + ']</span>' : '';
            var href = i.id ? invUrl(i.id) : "#";
            return '<a href="' + href + '" target="_blank" rel="noopener" title="id ' + i.id + ', total_ht ' + fmt(i.total_ht) + '">' + esc(label) + '</a>' + type;
        }).join(", ");
    }

    function actionCell(r) {
        var parts = [];
        if (r._excluded) {
            return '<span class="ebr-actiontag"><i class="fa fa-ban"></i> excluded</span>';
        }
        if (r._adjusted) {
            var a = r._adjusted;
            var label = a.action === 'credit_note' ? 'CN' : 'INV';
            var ref = a.newInvoiceRef || ('#' + a.newInvoiceId);
            parts.push('<span class="ebr-actiontag"><i class="fa fa-check"></i> ' + label + ' ' + esc(ref) + ' created</span>'
                + ' <a href="' + (a.dolibarrEditUrl || '#') + '" target="_blank" rel="noopener" style="font-size:11px;">view</a>');
        }
        if (r._paid) {
            var p = r._paid;
            if (p.summary && p.summary.paid > 0) {
                parts.push('<span class="ebr-actiontag paid"><i class="fa fa-money-check-alt"></i> paid ' + (p.summary.totalPaid||0).toFixed(2) + '</span>');
            } else if (p.summary && p.summary.failed > 0) {
                parts.push('<span class="ebr-actiontag notapplied"><i class="fa fa-exclamation-triangle"></i> pay failed</span>');
            } else if (p.summary && p.summary.skipped > 0) {
                parts.push('<span class="ebr-actiontag"><i class="fa fa-check"></i> no balance</span>');
            }
        }
        if (parts.length) return parts.join(' ');

        if (!state.writePerm) {
            if (r.status === 'MATCH' && (r.invoices || []).some(function (i) { return i.type === 'invoice'; }) && !hasPayableInvoice(r)) {
                return '<span class="ebr-actiontag paid"><i class="fa fa-check-circle"></i> already paid</span>';
            }
            return '';
        }

        // MATCH rows with any non-zero diff need an adjustment document.
        if (r.status === 'MATCH') {
            var matchDiff = Number(r.diff || 0);
            if (Math.abs(matchDiff) > 0) {
                var matchTarget = pickLargestInvoice(r);
                if (matchTarget) {
                    var matchCN = docTypeForRow(r) === 'credit_note';
                    return '<button class="button" data-approve="' + esc(r.order_number) + '"><i class="fa ' + (matchCN ? 'fa-file-invoice-dollar' : 'fa-file-invoice') + '"></i> ' + docLabel(r) + '</button>';
                }
                var missingDocCN = docTypeForRow(r) === 'credit_note';
                return '<button class="button" data-create="' + esc(r.order_number) + '"><i class="fa ' + (missingDocCN ? 'fa-file-invoice-dollar' : 'fa-file-invoice') + '"></i> ' + docLabel(r) + '</button>';
            }
            if ((r.invoices || []).some(function (i) { return i.type === 'invoice'; }) && !hasPayableInvoice(r)) {
                return '<span class="ebr-actiontag paid"><i class="fa fa-check-circle"></i> already paid</span>';
            }
            return '';
        }

        var isCN = docTypeForRow(r) === 'credit_note';
        var icon = isCN ? 'fa-file-invoice-dollar' : 'fa-file-invoice';
        if (r.status === 'MISMATCH') {
            var target = pickLargestInvoice(r);
            if (!target) return '<span class="ebr-sub">no parent</span>';
            return '<button class="button" data-approve="' + esc(r.order_number) + '"><i class="fa ' + icon + '"></i> ' + docLabel(r) + '</button>';
        }
        if (r.status === 'MISSING_IN_DOLIBARR' || r.status === 'NO_LINKED_INVOICES' || r.status === 'NO_ORDER_NUMBER') {
            // Zero dollar impact (e.g. a refund that washes against its order, a
            // cancelled order, or offsetting no-order lines) — nothing to post.
            // Offer Exclude instead of creating a document; only allowed because it
            // can't create a balance issue.
            if (Math.abs(Number(r.diff || 0)) <= 0.01) {
                return '<button class="button" data-exclude="' + esc(r.order_number) + '"><i class="fa fa-ban"></i> Exclude</button>';
            }
            return '<button class="button" data-create="' + esc(r.order_number) + '"><i class="fa ' + icon + '"></i> ' + docLabel(r) + '</button>';
        }
        return '';
    }

    function noteCell(r) {
        var status = r._noteStatus
            ? '<span class="ebr-note-status' + (r._noteStatusError ? ' err' : '') + '">' + esc(r._noteStatus) + '</span>'
            : '';
        var isEditing = !!r._noteEditing;
        var hasNote = !!(r.notes && String(r.notes).trim() !== '');
        if (!state.writePerm) {
            return hasNote
                ? '<div class="ebr-note-view">' + esc(r.notes) + '</div>' + status
                : status;
        }
        if (isEditing) {
            return ''
                + '<textarea class="ebr-note-input' + (r._noteSaving ? ' is-saving' : '') + '"'
                + ' data-note-order="' + esc(r.order_number) + '"'
                + ' placeholder="' + esc(t('NotesPlaceholder', 'Add a note for this order')) + '">'
                + esc(r._noteDraft !== undefined ? r._noteDraft : (r.notes || '')) + '</textarea>'
                + '<div class="ebr-note-actions">'
                + '<button class="button" type="button" data-note-save="' + esc(r.order_number) + '">' + esc(t('SaveNote', 'Save note')) + '</button>'
                + '<button class="button" type="button" data-note-cancel="' + esc(r.order_number) + '">' + esc(t('Cancel', 'Cancel')) + '</button>'
                + '</div>'
                + status;
        }
        return ''
            + (hasNote ? '<div class="ebr-note-view">' + esc(r.notes) + '</div>' : '')
            + '<div class="ebr-note-actions">'
            + '<button class="button" type="button" data-note-edit="' + esc(r.order_number) + '">'
            + esc(hasNote ? t('EditNote', 'Edit note') : uploadT('AddNote', 'Add note'))
            + '</button>'
            + '</div>'
            + status;
    }

    function esc(s) {
        if (s === null || s === undefined) return '';
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function unresolvedRows() {
        return state.results.filter(function (r) {
            return (r.status === 'MISMATCH' && !r._adjusted)
                || (r.status === 'MATCH' && !r._adjusted && Math.abs(Number(r.diff || 0)) > 0.01)
                || (r.status === 'MISSING_IN_DOLIBARR' && !r._adjusted && !r._excluded)
                || (r.status === 'NO_LINKED_INVOICES' && !r._adjusted && !r._excluded)
                || (r.status === 'NO_ORDER_NUMBER' && !r._adjusted && !r._excluded);
        });
    }
    function liveOutstanding() {
        // This is the workflow outstanding shown in the page header: only rows
        // that still need an action count here. Resolved rows may still appear in
        // the audit/export totals, but they should not keep the live work queue
        // amber after Approve/Create/Exclude are all complete.
        return Math.round(unresolvedRows().reduce(function (sum, r) {
            return sum + Number(r.diff || 0);
        }, 0) * 100) / 100;
    }
    function hasPayableInvoice(r) {
        return (r.invoices || []).some(function (i) {
            return i.type === 'invoice' && Number(i.remain_to_pay || 0) > 0.00001;
        });
    }
    function rowNetPayable(r) {
        var net = (r.invoices || []).reduce(function (sum, inv) {
            return sum + Number(inv.remain_to_pay || 0);
        }, 0);
        return Math.max(0, Math.round(net * 100) / 100);
    }
    function approveActionForRow(r) {
        // The correcting document follows the eBay transaction type, not the diff
        // sign: a refund issues a credit note, everything else an invoice.
        return docTypeForRow(r);
    }
    function recalcRowAfterAdjustment(row, action, newInvoiceId, newInvoiceRef, amount, signedAmountOverride) {
        if (!row) return;
        var signedAmount = signedAmountOverride !== undefined && signedAmountOverride !== null
            ? Number(signedAmountOverride || 0)
            : (action === 'credit_note' ? -Math.abs(Number(amount || 0)) : Math.abs(Number(amount || 0)));
        row.invoices = row.invoices || [];
        row.invoices.push({
            id: Number(newInvoiceId || 0),
            ref: newInvoiceRef || ('#' + newInvoiceId),
            type: action === 'credit_note' ? 'credit_note' : 'invoice',
            total_ht: signedAmount,
            is_paid: action === 'credit_note',
            // Keep remain consistent with the signed amount so the audit summary
            // (which sums remain_to_pay) matches this row's dolibarr_net.
            remain_to_pay: signedAmount,
        });
        row.dolibarr_net = Number(row.dolibarr_net || 0) + signedAmount;
        var ebay = Number(row.ebay_net || 0);
        var dol = Number(row.dolibarr_net || 0);
        // Consistent with the backend: diff is always eBay - Dolibarr.
        var nextDiff = Number((ebay - dol).toFixed(2));
        row.diff = nextDiff;
        if (Math.abs(nextDiff) <= 0.01) {
            row.status = 'MATCH';
            row.notes = row.notes || '';
        } else {
            row.status = 'MISMATCH';
        }
    }
    function rowsToPay() {
        return state.results.filter(function (r) {
            return !r._paid && rowNetPayable(r) > 0.01 && (r._adjusted || r.status === 'MATCH');
        });
    }
    function eligibleMismatches() {
        return state.results.filter(function (r) {
            return r.status === 'MISMATCH' && !r._adjusted && pickLargestInvoice(r);
        });
    }
    function eligibleCreates() {
        return state.results.filter(function (r) {
            var matchWithoutParent = r.status === 'MATCH' && !pickLargestInvoice(r);
            return (matchWithoutParent || r.status === 'MISSING_IN_DOLIBARR' || r.status === 'NO_LINKED_INVOICES' || r.status === 'NO_ORDER_NUMBER')
                && !r._adjusted && !r._excluded
                && Math.abs(Number(r.diff || 0)) > 0.01;  // zero-impact rows are Exclude-only, not Create
        });
    }
    function eligibleExcludes() {
        // Zero-impact rows that currently offer the per-row Exclude button.
        return state.results.filter(function (r) {
            return (r.status === 'MISSING_IN_DOLIBARR' || r.status === 'NO_LINKED_INVOICES' || r.status === 'NO_ORDER_NUMBER')
                && !r._adjusted && !r._excluded && !r._paid
                && Math.abs(Number(r.diff || 0)) <= 0.01;
        });
    }
    function eligibleMatchAdjustments() {
        return state.results.filter(function (r) {
            return r.status === 'MATCH' && !r._adjusted
                && Math.abs(Number(r.diff || 0)) > 0
                && !!pickLargestInvoice(r);
        });
    }

    // ---------- Rendering ----------

    function render() {
        var q = state.query.trim().toLowerCase();
        var rows = state.results.slice();
        if (state.filter !== 'ALL') rows = rows.filter(function (r) { return r.status === state.filter; });
        if (q) {
            rows = rows.filter(function (r) {
                var hay = [r.order_number, r.dolibarr_order_ref].concat((r.invoices||[]).map(function(i){return i.ref||'';})).join(' ').toLowerCase();
                return hay.indexOf(q) !== -1;
            });
        }
        var k = state.sortKey, dir = state.sortDir;
        if (k) {
            var numericKeys = { ebay_net:1, dolibarr_net:1, diff:1 };
            rows.sort(function (a, b) {
                var av = a[k], bv = b[k];
                if (k === 'invoice_refs') {
                    av = (a.invoices||[]).map(function(i){return i.ref||'';}).join(',');
                    bv = (b.invoices||[]).map(function(i){return i.ref||'';}).join(',');
                }
                if (numericKeys[k]) { av = Number(av); bv = Number(bv); }
                if (av === undefined || av === null) av = '';
                if (bv === undefined || bv === null) bv = '';
                if (av < bv) return -1 * dir;
                if (av > bv) return  1 * dir;
                return 0;
            });
        }

        var tbody = document.getElementById('ebrTbody');
        if (rows.length === 0) {
            tbody.innerHTML = '';
            document.getElementById('ebrEmpty').hidden = false;
        } else {
            document.getElementById('ebrEmpty').hidden = true;
            tbody.innerHTML = rows.map(function (r, i) {
                return '<tr class="' + (i % 2 === 0 ? 'pair' : 'impair') + '">'
                    + '<td><span class="ebr-badge ' + r.status + '">' + r.status.replace(/_/g, ' ') + '</span></td>'
                    + '<td><strong>' + esc(r.order_number) + '</strong></td>'
                    + '<td>' + typeCell(r) + '</td>'
                    + '<td class="num">' + ebayNetCell(r) + '</td>'
                    + '<td class="num">' + fmt(r.dolibarr_net) + '</td>'
                    + '<td class="num">' + diffCell(r.diff) + '</td>'
                    + '<td>' + (r.dolibarr_order_ref && r.dolibarr_order_id ? '<a href="' + soUrl(r.dolibarr_order_id) + '" target="_blank" rel="noopener">' + esc(r.dolibarr_order_ref) + '</a>' : esc(r.dolibarr_order_ref || '')) + '</td>'
                    + '<td>' + invoicesCell(r) + '</td>'
                    + '<td class="ebr-cell-notes">' + noteCell(r) + '</td>'
                    + '<td>' + actionCell(r) + '</td>'
                + '</tr>';
            }).join('');
        }

        // Update sort indicators
        document.querySelectorAll('#ebrTable th[data-key]').forEach(function (th) {
            th.classList.remove('sort-asc', 'sort-desc');
            if (th.dataset.key === state.sortKey) th.classList.add(state.sortDir === 1 ? 'sort-asc' : 'sort-desc');
        });

        // Update chip counts
        var totals = { ALL: state.results.length, MATCH: 0, MISMATCH: 0, MISSING_IN_DOLIBARR: 0, NO_LINKED_INVOICES: 0 };
        state.results.forEach(function (r) { totals[r.status] = (totals[r.status] || 0) + 1; });
        document.querySelectorAll('.ebr-chip .ebr-count').forEach(function (el) {
            el.textContent = totals[el.dataset.count] || 0;
        });

        // Live summary tiles (recomputed from the current row states, so they
        // update as documents are created/approved/excluded).
        var tileCount = { ALL: state.results.length };
        state.results.forEach(function (r) { tileCount[r.status] = (tileCount[r.status] || 0) + 1; });
        document.querySelectorAll('.ebr-num[data-tile]').forEach(function (el) {
            el.textContent = (tileCount[el.dataset.tile] != null) ? tileCount[el.dataset.tile] : 0;
        });

        // Live tie-out + status. Keep eBay's internal file check separate from
        // Dolibarr reconciliation: the eBay statement can tie to itself while
        // Dolibarr still has unresolved rows/documents.
        var stEl = document.getElementById('ebrTieState');
        if (stEl) {
            var T = fileTotals();
            var net = Number(T.netPayout || 0);
            // eBay payout amount = the statement's stated payout when present,
            // otherwise the computed net (which then ties to itself).
            var hasStated = T.statedPayout !== null && T.statedPayout !== undefined;
            var pay = hasStated ? Number(T.statedPayout) : net;
            var setV = function (id, v) { var e = document.getElementById(id); if (e) e.textContent = fmt(v); };
            setV('ebrTieGross', (T.grossSales !== null && T.grossSales !== undefined) ? T.grossSales : net);
            setV('ebrTieDebits', T.debits);
            setV('ebrTieCredits', T.credits);
            setV('ebrTieNet', net);
            setV('ebrTiePayout', pay);
            var fileCheck = document.getElementById('ebrFileTieCheck');
            if (fileCheck) {
                if (hasStated) {
                    fileCheck.className = 'ebr-tieout-check ' + (T.tiesOut ? 'ok' : 'bad');
                    fileCheck.innerHTML = T.tiesOut
                        ? '<i class="fa fa-check-circle"></i> eBay file check OK: calculated net equals the statement payout.'
                        : '<i class="fa fa-exclamation-triangle"></i> eBay file check off by ' + fmt(T.tieDiff) + '.';
                } else {
                    fileCheck.className = 'ebr-tieout-check neutral';
                    fileCheck.innerHTML = '<i class="fa fa-info-circle"></i> No eBay statement payout found; using calculated eBay net.';
                }
            }
            // Dolibarr outstanding uses the same sign as the row Diff column:
            // eBay - Dolibarr. Positive means Dolibarr is short (invoice); negative
            // means Dolibarr is high (credit note). It closes to 0 as rows resolve.
            var nUnresolved = unresolvedRows().length;
            var outstanding = liveOutstanding();
            setV('ebrTieDiff', outstanding);
            // "Reconciled" is driven by the SAME live work-queue number shown in
            // the Outstanding row, so the two can never contradict. Audit/export
            // document totals can still show their own diagnostic difference, but
            // they should not block the live workflow once every row is resolved.
            var outstandingClear = Math.abs(outstanding) <= 0.01;
            // A previously-settled payout is reconciled by definition — the page is
            // read-only and must never re-open the work as if it were pending.
            var reconciled = state.alreadySettled || (outstandingClear && nUnresolved === 0);
            stEl.className = 'ebr-tieout-state ' + (reconciled ? 'reconciled' : 'pending');
            stEl.innerHTML = '<i class="fa fa-' + (reconciled ? 'check-circle' : 'exclamation-circle') + '"></i> '
                + (state.alreadySettled
                    ? 'Already reconciled'
                    : (reconciled
                        ? 'Reconciled'
                        : (nUnresolved > 0
                            ? 'Dolibarr not reconciled (resolve ' + nUnresolved + ')'
                            : 'Dolibarr not reconciled (off by ' + fmt(outstanding) + ')')));
        }

        // Lock the complete action toolbar while a mutation is in flight. This
        // prevents overlapping batches and exporting/saving half-updated data.
        var operationBusy = state.activeOperations > 0;
        var busyTitle = 'Please wait — the current operation is still running.';

        // Bulk buttons
        var bulkM = document.getElementById('ebrBulkApproveMatches');
        if (bulkM) {
            var nm = eligibleMatchAdjustments().length;
            var bulkMDisabled = operationBusy || nm === 0;
            bulkM.hidden = !state.writePerm;
            bulkM.disabled = bulkMDisabled;
            bulkM.classList.toggle('ebr-bulk-disabled', bulkMDisabled);
            bulkM.title = operationBusy ? busyTitle : '';
            bulkM.textContent = 'Approve all match adjustments (' + nm + ')';
        }
        var bulkA = document.getElementById('ebrBulkApprove');
        if (bulkA) {
            var n = eligibleMismatches().length;
            var bulkADisabled = operationBusy || n === 0;
            bulkA.hidden = !state.writePerm;
            bulkA.disabled = bulkADisabled;
            bulkA.classList.toggle('ebr-bulk-disabled', bulkADisabled);
            bulkA.title = operationBusy ? busyTitle : '';
            bulkA.textContent = 'Approve all mismatches (' + n + ')';
        }
        var bulkC = document.getElementById('ebrBulkCreate');
        if (bulkC) {
            var nc = eligibleCreates().length;
            var bulkCDisabled = operationBusy || nc === 0;
            bulkC.hidden = !state.writePerm;
            bulkC.disabled = bulkCDisabled;
            bulkC.classList.toggle('ebr-bulk-disabled', bulkCDisabled);
            bulkC.title = operationBusy ? busyTitle : '';
            bulkC.textContent = 'Create all documents (' + nc + ')';
        }
        var bulkX = document.getElementById('ebrBulkExclude');
        if (bulkX) {
            var nx = eligibleExcludes().length;
            var bulkXDisabled = operationBusy || nx === 0;
            bulkX.hidden = !state.writePerm;
            bulkX.disabled = bulkXDisabled;
            bulkX.classList.toggle('ebr-bulk-disabled', bulkXDisabled);
            bulkX.title = operationBusy ? busyTitle : '';
            bulkX.textContent = 'Exclude all zero-balance (' + nx + ')';
        }
        var bulkP = document.getElementById('ebrBulkPay');
        if (bulkP) {
            var unresolved = unresolvedRows().length;
            var toPay = rowsToPay().length;
            var ready = state.writePerm && state.payout && state.payout.id && state.payout.date_unix;
            var bulkPDisabled = operationBusy || !ready || unresolved > 0 || toPay === 0;
            bulkP.hidden = !state.writePerm;
            bulkP.style.display = '';
            bulkP.disabled = bulkPDisabled;
            bulkP.classList.toggle('ebr-bulk-disabled', bulkPDisabled);
            bulkP.title = operationBusy ? busyTitle : '';
            bulkP.style.opacity = '';
            bulkP.textContent = unresolved > 0
                ? 'Pay all (resolve ' + unresolved + ' first)'
                : 'Pay all (' + toPay + ')';
        }
        // Save draft: a draft only makes sense for work in progress. Once everything
        // is settled (nothing left to pay AND nothing unresolved) there is nothing to
        // resume, so disable it — same "fully done" state that flips Pay all off.
        var saveBtn = document.getElementById('ebrSaveDraft');
        if (saveBtn) {
            var settled = unresolvedRows().length === 0 && rowsToPay().length === 0;
            saveBtn.disabled = settled || operationBusy;
            saveBtn.classList.toggle('ebr-bulk-disabled', settled || operationBusy);
            saveBtn.title = operationBusy
                ? 'Please wait — the current operation must finish before saving a draft.'
                : (settled
                    ? 'Nothing to save — this reconciliation is fully settled.'
                    : (state.i18n.SaveDraftHelp || 'Save your progress and resume this reconciliation later.'));
        }

        ['ebrDlCsv', 'ebrDlJson'].forEach(function (id) {
            var exportBtn = document.getElementById(id);
            if (!exportBtn) return;
            exportBtn.disabled = operationBusy;
            exportBtn.classList.toggle('ebr-bulk-disabled', operationBusy);
            exportBtn.title = operationBusy ? busyTitle : '';
        });
    }

    // ---------- AJAX helper ----------

    function jpost(action, payload) {
        return fetch(state.actionUrl + '?action=' + encodeURIComponent(action) + '&token=' + encodeURIComponent(state.token), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            credentials: 'same-origin',
        }).then(function (r) {
            return r.text().then(function (text) {
                if (!r.ok) throw new Error('HTTP ' + r.status + ': ' + text.slice(0, 300));
                try { return JSON.parse(text); }
                catch (_) { throw new Error('Response was not JSON: ' + text.slice(0, 300)); }
            });
        });
    }

    // ---------- Modals ----------

    function ensureModal(id, html) {
        if (document.getElementById(id)) return document.getElementById(id);
        var div = document.createElement('div');
        div.id = id;
        div.className = 'ebr-modal-bg';
        div.innerHTML = html;
        document.body.appendChild(div);
        return div;
    }

    function openActionConfirm(options, onConfirm) {
        var modal = ensureModal('ebrActionConfirmModal',
            '<div class="ebr-modal" style="width:500px;">'
            + '<div class="mhead"><i class="fa fa-question-circle"></i> <span id="ebrActionConfirmTitle"></span></div>'
            + '<div class="mbody"><p id="ebrActionConfirmMessage" style="margin:0;"></p>'
            + '<div class="mnote" id="ebrActionConfirmNote"></div></div>'
            + '<div class="mfoot"><button class="button" id="ebrActionConfirmCancel" type="button">Cancel</button>'
            + '<button class="butAction" id="ebrActionConfirmOk" type="button"></button></div>'
            + '</div>');

        document.getElementById('ebrActionConfirmTitle').textContent = options.title;
        document.getElementById('ebrActionConfirmMessage').textContent = options.message;
        var note = document.getElementById('ebrActionConfirmNote');
        note.textContent = options.note || '';
        note.hidden = !options.note;

        function close() { modal.classList.remove('open'); }
        document.getElementById('ebrActionConfirmCancel').onclick = close;
        var confirmBtn = document.getElementById('ebrActionConfirmOk');
        confirmBtn.textContent = options.confirmLabel || 'Confirm';
        confirmBtn.onclick = function () {
            close();
            onConfirm();
        };
        modal.classList.add('open');
        confirmBtn.focus();
    }

    function openApproveModal(orderNumber) {
        var r = state.results.find(function (x) { return x.order_number === orderNumber; });
        if (!r) return;
        var target = pickLargestInvoice(r);
        if (!target) { showToast('No parent invoice to credit against', true); return; }
        var diff = Number(r.diff);
        var action = approveActionForRow(r);
        var amount = Math.abs(diff);

        state.pending = {
            action: action,
            orderNumber: r.order_number,
            parentInvoiceId: target.id,
            amount: amount,
            note: r.notes || '',
        };

        var modal = ensureModal('ebrApproveModal',
            '<div class="ebr-modal" style="width:480px;">'
            + '<div class="mhead"><i class="fa fa-check-circle"></i> Approve adjustment</div>'
            + '<div class="mbody"><dl id="ebrApproveBody"></dl>'
            + '<div class="mnote">Confirm will create + validate the document in Dolibarr. The reconciler will pick it up alongside the existing invoice so the totals net out.</div>'
            + '<div id="ebrApproveErr" class="ebr-error" hidden></div></div>'
            + '<div class="mfoot"><button class="button" id="ebrApproveCancel">Cancel</button>'
            + '<button class="butAction" id="ebrApproveConfirm">Confirm</button></div>'
            + '</div>');

        var actionLabel = action === 'credit_note'
            ? '<strong style="color:#b3261e">Credit note</strong>'
            : '<strong style="color:#1e8a4a">Invoice (additional)</strong>';
        document.getElementById('ebrApproveBody').innerHTML =
            '<dt>Order</dt><dd><code>' + esc(r.order_number) + '</code></dd>' +
            '<dt>SO</dt><dd><code>' + esc(r.dolibarr_order_ref || '-') + '</code></dd>' +
            '<dt>eBay net</dt><dd>' + fmt(r.ebay_net) + '</dd>' +
            '<dt>Dolibarr net</dt><dd>' + fmt(r.dolibarr_net) + '</dd>' +
            '<dt>Diff</dt><dd>' + diffCell(r.diff) + '</dd>' +
            '<dt>Will create</dt><dd>' + actionLabel + ' for <strong>' + amount.toFixed(2) + '</strong></dd>' +
            '<dt>Linked to</dt><dd><code>' + esc(target.ref) + '</code> <span class="ebr-sub">(id ' + target.id + ')</span></dd>';

        var confirmBtn = document.getElementById('ebrApproveConfirm');
        confirmBtn.onclick = confirmApprove;
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirm';
        document.getElementById('ebrApproveCancel').onclick = function () { modal.classList.remove('open'); };
        document.getElementById('ebrApproveErr').hidden = true;
        modal.classList.add('open');
    }

    function confirmApprove() {
        if (!state.pending) return;
        var btn = document.getElementById('ebrApproveConfirm');
        btn.disabled = true; btn.textContent = 'Creating...';
        beginOperation();
        jpost('approve', state.pending).then(function (data) {
            if (!data.ok) throw new Error(data.error || 'n8n returned ok=false');
            var target = state.results.find(function (x) { return x.order_number === state.pending.orderNumber; });
            if (target) {
                target._adjusted = data;
                recalcRowAfterAdjustment(target, data.action, data.newInvoiceId, data.newInvoiceRef, data.amount);
            }
            showToast(data.message + ' <a href="' + data.dolibarrEditUrl + '" target="_blank">Open</a>', false);
            document.getElementById('ebrApproveModal').classList.remove('open');
            state.pending = null;
            render();
        }).catch(function (err) {
            document.getElementById('ebrApproveErr').textContent = err.message;
            document.getElementById('ebrApproveErr').hidden = false;
            btn.disabled = false; btn.textContent = 'Retry';
        }).then(endOperation, endOperation);
    }

    function openCreateInvoiceModal(orderNumber) {
        var r = state.results.find(function (x) { return x.order_number === orderNumber; });
        if (!r) return;
        var hasSO = !!r.dolibarr_order_id;
        var lines = (r.ebay_lines && r.ebay_lines.length > 0)
            ? r.ebay_lines
            : [{ date:'', type:'eBay sale', description: r.order_number, net: r.ebay_net }];

        var docType = docTypeForRow(r);
        var isCN = docType === 'credit_note';

        state.pendingCreate = {
            orderNumber: r.order_number,
            ebayNet: r.ebay_net,
            lines: lines,
            parentSoId: hasSO ? r.dolibarr_order_id : null,
            action: docType,
            note: r.notes || '',
        };
        if (!hasSO) state.pendingCreate.defaultSocid = selectedDefaultSocid();

        var modal = ensureModal('ebrCreateModal',
            '<div class="ebr-modal" style="width:520px;">'
            + '<div class="mhead" id="ebrCreateHead"></div>'
            + '<div class="mbody"><dl id="ebrCreateBody"></dl>'
            + '<div class="mnote" id="ebrCreateNote"></div>'
            + '<div id="ebrCreateErr" class="ebr-error" hidden></div></div>'
            + '<div class="mfoot"><button class="button" id="ebrCreateCancel">Cancel</button>'
            + '<button class="butAction" id="ebrCreateConfirm">Confirm</button></div>'
            + '</div>');
        document.getElementById('ebrCreateHead').innerHTML = isCN
            ? '<i class="fa fa-file-invoice-dollar"></i> Create credit note'
            : '<i class="fa fa-file-invoice"></i> Create missing invoice';
        document.getElementById('ebrCreateNote').textContent = isCN
            ? 'Confirm will create a credit note in Dolibarr (positive amount, issued to eBay — not applied to a source invoice), then validate it.'
            : 'Confirm will create the invoice in Dolibarr (one line per CSV row), then validate it.';

        var linesHtml = lines.map(function (l) {
            var n = Number(l.net || 0);
            var cls = n > 0 ? 'ebr-diff-pos' : (n < 0 ? 'ebr-diff-neg' : '');
            return '<div style="display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px solid #eef3f5;">'
                + '<span><span class="ebr-sub">' + esc(l.date||'') + '</span> ' + esc(l.type||'') + ' <span class="ebr-sub">' + esc((l.description||'').slice(0,40)) + '</span></span>'
                + '<span class="' + cls + '">' + n.toFixed(2) + '</span>'
                + '</div>';
        }).join('');

        var willCreate = isCN
            ? '<strong style="color:#b3261e">Credit note</strong> for <strong>' + Math.abs(Number(r.ebay_net || 0)).toFixed(2) + '</strong>'
            : '<strong style="color:#1e8a4a">Invoice</strong> for <strong>' + fmt(r.ebay_net) + '</strong>';
        document.getElementById('ebrCreateBody').innerHTML =
            '<dt>Order</dt><dd><code>' + esc(r.order_number) + '</code></dd>' +
            '<dt>Status</dt><dd>' + r.status.replace(/_/g, ' ') + '</dd>' +
            '<dt>eBay type</dt><dd>' + esc(r.ebay_type || (r.ebay_types || []).join(', ') || '-') + '</dd>' +
            (hasSO
                ? '<dt>Linking to SO</dt><dd><code>' + esc(r.dolibarr_order_ref) + '</code></dd>'
                : '<dt>Customer</dt><dd>' + esc(selectedDefaultCustomerLabel() || ('#' + selectedDefaultSocid())) + '</dd>') +
            '<dt>Will create</dt><dd>' + willCreate + '</dd>' +
            '<dt>Lines (' + lines.length + ')</dt><dd><div style="max-height:140px;overflow:auto;">' + linesHtml + '</div></dd>';

        var confirmBtn = document.getElementById('ebrCreateConfirm');
        confirmBtn.onclick = confirmCreate;
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirm';
        document.getElementById('ebrCreateCancel').onclick = function () { modal.classList.remove('open'); };
        document.getElementById('ebrCreateErr').hidden = true;
        modal.classList.add('open');
    }

    function confirmCreate() {
        if (!state.pendingCreate) return;
        var btn = document.getElementById('ebrCreateConfirm');
        btn.disabled = true; btn.textContent = 'Creating...';
        beginOperation();
        jpost('create_invoice', state.pendingCreate).then(function (data) {
            if (!data.ok) throw new Error(data.error || 'n8n returned ok=false');
            var target = state.results.find(function (x) { return x.order_number === state.pendingCreate.orderNumber; });
            if (target) {
                var act = data.action || 'invoice';
                target._adjusted = {
                    action: act,
                    newInvoiceId: data.newInvoiceId,
                    newInvoiceRef: data.newInvoiceRef,
                    applied: false,
                    dolibarrEditUrl: data.dolibarrEditUrl,
                };
                // Credit notes reduce the Dolibarr-side net (negative); invoices keep their sign.
                var signed = act === 'credit_note' ? -Math.abs(Number(data.totalHt || 0)) : Number(data.totalHt || 0);
                recalcRowAfterAdjustment(target, act, data.newInvoiceId, data.newInvoiceRef, Math.abs(Number(data.totalHt || 0)), signed);
            }
            showToast(data.message + ' <a href="' + data.dolibarrEditUrl + '" target="_blank">Open</a>', false);
            document.getElementById('ebrCreateModal').classList.remove('open');
            state.pendingCreate = null;
            render();
        }).catch(function (err) {
            document.getElementById('ebrCreateErr').textContent = err.message;
            document.getElementById('ebrCreateErr').hidden = false;
            btn.disabled = false; btn.textContent = 'Retry';
        }).then(endOperation, endOperation);
    }

    // ---------- Bulk actions ----------

    function runBulkApprove() {
        var elig = eligibleMismatches().map(function (r) {
            var target = pickLargestInvoice(r);
            var diff = Number(r.diff);
            return {
                row: r,
                payload: {
                    action: approveActionForRow(r),
                    orderNumber: r.order_number,
                    parentInvoiceId: target.id,
                    amount: Math.abs(diff),
                    note: r.notes || '',
                },
            };
        });
        if (!elig.length) return;
        openActionConfirm({
            title: 'Approve all mismatches',
            message: 'Approve and process ' + elig.length + ' mismatch(es)?',
            note: 'This will create and validate the required invoices or credit notes in Dolibarr.',
            confirmLabel: 'Approve ' + elig.length
        }, function () {
            beginOperation();
            showToast('Processing ' + elig.length + '...', false);
            var done = 0, ok = 0, fail = 0;
            var cursor = 0;
            function worker() {
                return new Promise(function (resolve) {
                    function next() {
                        if (cursor >= elig.length) return resolve();
                        var item = elig[cursor++];
                        jpost('approve', item.payload).then(function (data) {
                            if (data.ok) {
                                item.row._adjusted = data;
                                recalcRowAfterAdjustment(item.row, data.action, data.newInvoiceId, data.newInvoiceRef, data.amount);
                                ok++;
                            } else { fail++; }
                        }).catch(function () { fail++; }).then(function () {
                            done++; render(); next();
                        });
                    }
                    next();
                });
            }
            Promise.all([worker(), worker(), worker()]).then(function () {
                showToast('Bulk approve done: ' + ok + ' ok, ' + fail + ' failed', fail > 0);
            }).then(endOperation, endOperation);
        });
    }

    function runBulkApproveMatches() {
        var elig = eligibleMatchAdjustments().map(function (r) {
            var target = pickLargestInvoice(r);
            return {
                row: r,
                payload: {
                    action: docTypeForRow(r),
                    orderNumber: r.order_number,
                    parentInvoiceId: target.id,
                    amount: Math.abs(Number(r.diff)),
                    note: r.notes || '',
                },
            };
        });
        if (!elig.length) return;
        openActionConfirm({
            title: 'Approve match adjustments',
            message: 'Create adjustment documents for ' + elig.length + ' match row(s)?',
            note: 'This will create and validate the required adjustment documents in Dolibarr.',
            confirmLabel: 'Create ' + elig.length
        }, function () {
            beginOperation();
            showToast('Processing ' + elig.length + '...', false);
            var done = 0, ok = 0, fail = 0;
            var cursor = 0;
            function worker() {
                return new Promise(function (resolve) {
                    function next() {
                        if (cursor >= elig.length) return resolve();
                        var item = elig[cursor++];
                        jpost('approve', item.payload).then(function (data) {
                            if (data.ok) {
                                item.row._adjusted = data;
                                recalcRowAfterAdjustment(item.row, data.action, data.newInvoiceId, data.newInvoiceRef, data.amount);
                                ok++;
                            } else { fail++; }
                        }).catch(function () { fail++; }).then(function () {
                            done++; render(); next();
                        });
                    }
                    next();
                });
            }
            Promise.all([worker(), worker(), worker()]).then(function () {
                showToast('Match adjustments done: ' + ok + ' ok, ' + fail + ' failed', fail > 0);
            }).then(endOperation, endOperation);
        });
    }

    function runBulkCreate() {
        var elig = eligibleCreates().map(function (r) {
            var hasSO = !!r.dolibarr_order_id;
            var lines = (r.ebay_lines && r.ebay_lines.length > 0)
                ? r.ebay_lines
                : [{ date: '', type: 'eBay sale', description: r.order_number, net: r.ebay_net }];
            return {
                row: r,
                payload: {
                    orderNumber: r.order_number,
                    ebayNet: r.ebay_net,
                    lines: lines,
                    parentSoId: hasSO ? r.dolibarr_order_id : null,
                    action: docTypeForRow(r),
                    note: r.notes || '',
                },
            };
        }).map(function (item) {
            if (!item.payload.parentSoId) item.payload.defaultSocid = selectedDefaultSocid();
            return item;
        });
        if (!elig.length) return;
        openActionConfirm({
            title: 'Create all documents',
            message: 'Create ' + elig.length + ' document(s)?',
            note: 'Invoices and credit notes will be created and validated according to each row balance.',
            confirmLabel: 'Create ' + elig.length
        }, function () {
            beginOperation();
            showToast('Creating ' + elig.length + ' document(s)...', false);
            var ok = 0, fail = 0;
            var cursor = 0;
            function worker() {
                return new Promise(function (resolve) {
                    function next() {
                        if (cursor >= elig.length) return resolve();
                        var item = elig[cursor++];
                        jpost('create_invoice', item.payload).then(function (data) {
                            if (data && data.ok) {
                                var act = data.action || 'invoice';
                                item.row._adjusted = {
                                    action: act,
                                    newInvoiceId: data.newInvoiceId,
                                    newInvoiceRef: data.newInvoiceRef,
                                    applied: false,
                                    dolibarrEditUrl: data.dolibarrEditUrl,
                                };
                                var signed = act === 'credit_note'
                                    ? -Math.abs(Number(data.totalHt || 0))
                                    : Number(data.totalHt || 0);
                                recalcRowAfterAdjustment(item.row, act, data.newInvoiceId, data.newInvoiceRef, Math.abs(Number(data.totalHt || 0)), signed);
                                ok++;
                            } else { fail++; }
                        }).catch(function () { fail++; }).then(function () {
                            render(); next();
                        });
                    }
                    next();
                });
            }
            Promise.all([worker(), worker(), worker()]).then(function () {
                showToast('Bulk create done: ' + ok + ' created, ' + fail + ' failed', fail > 0);
            }).then(endOperation, endOperation);
        });
    }

    function runBulkExclude() {
        // Client-side only, like the per-row Exclude: zero-balance rows that have
        // nothing to post. The guard mirrors the single-row path so a non-zero
        // balance can never be hidden.
        var elig = eligibleExcludes();
        if (!elig.length) return;
        openActionConfirm({
            title: 'Exclude zero-balance lines',
            message: 'Exclude ' + elig.length + ' zero-balance line(s)?',
            note: 'Nothing will be posted to Dolibarr. These lines will be dismissed from this reconciliation.',
            confirmLabel: 'Exclude ' + elig.length
        }, function () {
            var n = 0;
            elig.forEach(function (r) {
                if (Math.abs(Number(r.diff || 0)) > 0.01) return;
                r._excluded = { at: 'bulk' };
                r.status = 'MATCH';
                r.diff = 0;
                n++;
            });
            showToast('Excluded ' + n + ' zero-balance line(s).', false);
            render();
        });
    }

    function runBulkPay() {
        if (unresolvedRows().length > 0) {
            showToast('Resolve all mismatches / missing rows first.', true);
            return;
        }
        var elig = rowsToPay();
        if (!elig.length) return;
        openBulkPayModal(elig);
    }

    function openBulkPayModal(elig) {
        state.pendingBulkPay = elig.slice();
        var modal = ensureModal('ebrBulkPayModal',
            '<div class="ebr-modal" style="width:520px;">'
            + '<div class="mhead"><i class="fa fa-money-check-alt"></i> Pay all matched orders</div>'
            + '<div class="mbody"><dl id="ebrBulkPayBody"></dl>'
            + '<div class="mnote">Confirm will record payments in Dolibarr using this payout reference. Rows with no remaining balance will be skipped automatically.</div>'
            + '<div id="ebrBulkPayErr" class="ebr-error" hidden></div></div>'
            + '<div class="mfoot"><button class="button" id="ebrBulkPayCancel">Cancel</button>'
            + '<button class="butAction" id="ebrBulkPayConfirm">Confirm</button></div>'
            + '</div>');

        var totalRemain = elig.reduce(function (sum, row) {
            return sum + rowNetPayable(row);
        }, 0);
        var T = fileTotals();
        var tie = '';
        if (T.grossSales !== null && T.grossSales !== undefined) {
            tie += '<dt>Gross sales</dt><dd>' + fmt(T.grossSales) + '</dd>';
        }
        tie += '<dt>eBay debits (+)</dt><dd class="ebr-diff-pos">' + fmt(T.debits) + '</dd>';
        tie += '<dt>eBay credits (-)</dt><dd class="ebr-diff-neg">' + fmt(T.credits) + '</dd>';
        tie += '<dt>eBay calculated net</dt><dd><strong>' + fmt(T.netPayout) + '</strong></dd>';
        if (T.statedPayout !== null && T.statedPayout !== undefined) {
            tie += '<dt>eBay statement payout</dt><dd><strong>' + fmt(T.statedPayout) + '</strong></dd>';
            tie += T.tiesOut
                ? '<dt></dt><dd class="ebr-diff-pos"><i class="fa fa-check-circle"></i> eBay file check OK</dd>'
                : '<dt></dt><dd class="ebr-diff-neg"><i class="fa fa-exclamation-triangle"></i> eBay file off by ' + fmt(T.tieDiff) + '</dd>';
        }
        document.getElementById('ebrBulkPayBody').innerHTML =
            '<dt>Payout</dt><dd><code>' + esc(state.payout.id) + '</code></dd>' +
            '<dt>Payout date</dt><dd>' + esc(state.payout.date || '-') + '</dd>' +
            tie +
            '<dt>Orders to pay</dt><dd><strong>' + elig.length + '</strong></dd>' +
            '<dt>Payments to record now</dt><dd><strong>' + totalRemain.toFixed(2) + '</strong> <span class="ebr-sub">(net due after credit notes/adjustments)</span></dd>';

        var confirmBtn = document.getElementById('ebrBulkPayConfirm');
        confirmBtn.onclick = confirmBulkPay;
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirm';
        document.getElementById('ebrBulkPayCancel').onclick = function () {
            modal.classList.remove('open');
            state.pendingBulkPay = null;
        };
        document.getElementById('ebrBulkPayErr').hidden = true;
        modal.classList.add('open');
    }

    // After a successful pay, reflect it in the in-memory results so the report
    // and the paid column update without waiting for a fresh reconcile. Matches
    // by invoice id against the backend's payments[] (newly paid) and skipped[]
    // (already zero-balance); credit notes are never "paid" by this path.
    function markRowInvoicesPaid(row, data) {
        if (!row || !row.invoices || !data) return;
        var paidById = {};
        (data.payments || []).forEach(function (p) {
            if (p && p.invoiceId != null) paidById[String(p.invoiceId)] = Number(p.amount || 0);
        });
        (data.skipped || []).forEach(function (sk) {
            if (sk && sk.invoiceId != null && Number(sk.net_due || 0) <= 0) paidById[String(sk.invoiceId)] = 0;
        });
        row.invoices.forEach(function (inv) {
            if (inv.type === 'invoice' && paidById[String(inv.id)] !== undefined) {
                var paid = Number(paidById[String(inv.id)] || 0);
                inv.remain_to_pay = Math.max(0, Math.round((Number(inv.remain_to_pay || 0) - paid) * 100) / 100);
                inv.is_paid = inv.is_paid || inv.remain_to_pay <= 0.01;
            }
        });
    }

    function confirmBulkPay() {
        var elig = state.pendingBulkPay || [];
        if (!elig.length) return;
        var btn = document.getElementById('ebrBulkPayConfirm');
        btn.disabled = true;
        btn.textContent = 'Paying...';
        beginOperation();
        showToast('Paying ' + elig.length + '...', false);
        var done = 0, ok = 0, fail = 0, noop = 0;
        var cursor = 0;
        function worker() {
            return new Promise(function (resolve) {
                function next() {
                    if (cursor >= elig.length) return resolve();
                    var row = elig[cursor++];
                    var payload = {
                        orderNumber: row.order_number,
                        payoutId: state.payout.id,
                        payoutDateUnix: state.payout.date_unix,
                        note: row.notes || '',
                    };
                    jpost('pay', payload).then(function (data) {
                        row._paid = data;
                        // Pay All records payments in Dolibarr, but the report/paid
                        // column read the in-memory results - reflect the new paid
                        // state here so they don't stay stale until a re-reconcile.
                        // Mark every invoice the backend just paid (or skipped as
                        // already zero-balance) as paid with no remaining balance.
                        markRowInvoicesPaid(row, data);
                        // Three distinct outcomes:
                        //   - paid > 0:   real payment recorded → ok
                        //   - failed > 0: something errored in Dolibarr → fail
                        //   - paid = 0, failed = 0, skipped > 0: nothing to pay
                        //     (already paid or zero-balance invoice) → no-op
                        if (data && data.summary && data.summary.paid > 0) ok++;
                        else if (data && data.summary && data.summary.failed > 0) fail++;
                        else noop++;
                    }).catch(function (err) {
                        // Always mark the row as attempted, so it's removed from
                        // rowsToPay() and the bulk counter doesn't linger at "1"
                        // after a transient network/parse error.
                        row._paid = {
                            ok: false,
                            summary: { paid: 0, failed: 1, skipped: 0, totalPaid: 0 },
                            error: (err && err.message) ? err.message : 'unknown'
                        };
                        fail++;
                    }).then(function () {
                        done++; render(); next();
                    });
                }
                next();
            });
        }
        Promise.all([worker(), worker(), worker()]).then(function () {
            var modal = document.getElementById('ebrBulkPayModal');
            if (modal) modal.classList.remove('open');
            state.pendingBulkPay = null;
            // Record the settled summary when anything was actually paid OR when the
            // payout is now fully settled with no failures — even if this run recorded
            // no NEW payments (e.g. the invoices were already paid from a prior run).
            // Otherwise a re-paid, already-settled payout would never reach History.
            var fullySettled = fail === 0 && rowsToPay().length === 0 && unresolvedRows().length === 0;
            var saveSummary = (ok > 0 || fullySettled) ? savePayoutSummary() : Promise.resolve();
            return saveSummary.then(function () {
                var bits = [ok + ' paid'];
                if (fail > 0) bits.push(fail + ' failed');
                if (noop > 0) bits.push(noop + ' nothing to pay');
                showToast('Bulk pay done: ' + bits.join(', '), fail > 0);
            });
        }).catch(function (err) {
            var errBox = document.getElementById('ebrBulkPayErr');
            if (errBox) {
                errBox.textContent = err && err.message ? err.message : 'Bulk pay failed';
                errBox.hidden = false;
            }
            showToast((err && err.message) ? err.message : 'Bulk pay failed', true);
            btn.disabled = false;
            btn.textContent = 'Retry';
        }).then(endOperation, endOperation);
    }

    function savePayoutSummary() {
        if (!state.payout || !state.payout.id) return Promise.resolve();
        if (unresolvedRows().length > 0 || Math.abs(liveOutstanding()) > 0.01) {
            return Promise.reject(new Error('Cannot settle this payout while reconciliation work remains.'));
        }
        var paidRows = state.results.filter(function (r) { return r._paid && r._paid.summary && r._paid.summary.paid > 0; });
        // Don't bail when nothing was freshly paid: a payout whose invoices were
        // already paid in a prior run is still settled and must reach History. We fall
        // back to the already-paid matched orders / the payout net below.
        var items = [];
        var totalPaid = 0;
        paidRows.forEach(function (r) {
            (r._paid.payments || []).forEach(function (p) {
                var amt = Number(p.amount || 0);
                totalPaid += amt;
                items.push({
                    orderNumber: r.order_number,
                    soRef: r.dolibarr_order_ref,
                    soId: r.dolibarr_order_id,
                    invoiceRef: p.invoiceRef,
                    invoiceId: p.invoiceId,
                    amount: Math.round(amt * 100) / 100,
                    paymentId: p.paymentId,
                });
            });
        });
        var T = fileTotals();
        // Orders considered settled: those freshly paid this run, plus those whose
        // invoices were already paid (matched with a paid invoice). Used for the count
        // and the fallback total when no new payment was recorded.
        var settledRows = state.results.filter(function (r) {
            return (r._paid && r._paid.summary && r._paid.summary.paid > 0)
                || (r.invoices || []).some(function (i) { return i.type === 'invoice' && i.is_paid; });
        });
        var ordersCount = paidRows.length > 0 ? paidRows.length : settledRows.length;
        // When nothing was freshly paid, the payout is settled but this run moved no
        // money — record the payout's net as the settled amount so History is meaningful.
        var settledTotal = totalPaid > 0 ? totalPaid : Number(T.netPayout || 0);
        // Persist the full report so the CSV can be re-downloaded from History later
        // (no need to keep the browser tab open or re-upload the payout).
        var fullReport = (window.EBR_EXPORT && window.EBR_EXPORT.build)
            ? window.EBR_EXPORT.build(state.results, state.totals, state.payout, state.sourceFile, { defaultSocid: selectedDefaultSocid(), defaultCustomerLabel: selectedDefaultCustomerLabel() })
            : null;
        return jpost('save_payout', {
            payoutId: state.payout.id,
            payoutDate: state.payout.date,
            payoutMethod: state.payout.method,
            sourceFile: state.sourceFile,
            ordersCount: ordersCount,
            paymentsCount: items.length,
            totalPaid: Math.round(settledTotal * 100) / 100,
            grossSales: T.grossSales,
            totalDebits: T.debits,
            totalCredits: T.credits,
            netPayout: T.netPayout,
            statedPayout: (state.totals && state.totals.statedPayout != null) ? state.totals.statedPayout : null,
            ebayPayout: (state.totals && state.totals.statedPayout != null) ? state.totals.statedPayout : T.netPayout,
            dolibarrNet: (state.totals && state.totals.statedPayout != null) ? state.totals.statedPayout : T.netPayout,
            diff: 0,
            items: items,
            report: fullReport,
            // Full reconciled row state, so re-opening a settled payout REPLAYS the
            // state it was settled in (all resolved) instead of re-matching against the
            // now-paid invoices — which would falsely read as mismatches (paid invoices
            // have 0 remaining due). Mirrors the draft state_json.
            state: {
                results:    state.results,
                payout:     state.payout,
                totals:     state.totals,
                sourceFile: state.sourceFile,
                defaultSocid: selectedDefaultSocid(),
                defaultCustomerLabel: selectedDefaultCustomerLabel()
            }
        });
    }

    // ---------- Save draft ----------

    // Persist the current reconciliation (rows + every resolution/note + payout) so
    // the user can leave and resume later from List Reconciliations. The summary
    // totals are also stored so the List can show how the math currently stands.
    function saveDraft() {
        if (!state.payout || !state.payout.id) { showToast(t('NothingToSave', 'Nothing to save yet — reconcile a payout first.'), true); return; }
        var btn = document.getElementById('ebrSaveDraft');
        var statusEl = document.getElementById('ebrDraftStatus');
        if (btn) btn.disabled = true;
        if (statusEl) { statusEl.className = 'ebr-draft-status'; statusEl.textContent = t('Saving', 'Saving...'); }

        var sum = (window.EBR_EXPORT && window.EBR_EXPORT.build)
            ? window.EBR_EXPORT.build(state.results, state.totals, state.payout, state.sourceFile, { defaultSocid: selectedDefaultSocid(), defaultCustomerLabel: selectedDefaultCustomerLabel() }).summary
            : {};
        var dNet = Math.round((Number(sum.ebay_net_payout || 0) - Number(sum.dolibarr_outstanding || 0)) * 100) / 100;
        var ePay = Math.round(Number(sum.ebay_net_payout || 0) * 100) / 100;
        var T = fileTotals();
        var listTotals = {
            grossSales:   T.grossSales,
            debits:       T.debits,
            credits:      T.credits,
            netPayout:    T.netPayout,
            statedPayout: (state.totals && state.totals.statedPayout != null) ? state.totals.statedPayout : null,
            dolibarrNet:  dNet,
            ebayPayout:   ePay,
            diff:         liveOutstanding()
        };

        return jpost('save_draft', {
            payoutId:     state.payout.id,
            payoutDate:   state.payout.date,
            payoutMethod: state.payout.method,
            sourceFile:   state.sourceFile,
            ordersCount:  state.results.length,
            totalPaid:    dNet,
            totals:       listTotals,
            // Full state for resume: rows carry their _adjusted/_paid/_excluded/notes.
            state: {
                results:    state.results,
                payout:     state.payout,
                totals:     state.totals,
                sourceFile: state.sourceFile,
                defaultSocid: selectedDefaultSocid(),
                defaultCustomerLabel: selectedDefaultCustomerLabel()
            }
        }).then(function (data) {
            if (!data.ok) throw new Error(data.error || 'save_draft failed');
            state.draftId = data.id;
            if (statusEl) statusEl.textContent = t('Saved', 'Saved');
            showToast('<i class="fa fa-check"></i> ' + t('DraftSaved', 'Draft saved — resume any time from List Reconciliations.'));
            setTimeout(function () { if (statusEl && statusEl.textContent === t('Saved', 'Saved')) statusEl.textContent = ''; }, 2500);
        }).catch(function (err) {
            if (statusEl) { statusEl.className = 'ebr-draft-status err'; statusEl.textContent = ''; }
            showToast('<i class="fa fa-exclamation-triangle"></i> ' + (err.message || 'Draft save failed'), true);
        }).then(function () { if (btn) btn.disabled = false; });
    }

    // ---------- Toast ----------

    function showToast(html, isError) {
        var prev = document.querySelector('.ebr-toast');
        if (prev) prev.remove();
        var t = document.createElement('div');
        t.className = 'ebr-toast' + (isError ? ' err' : '');
        t.innerHTML = html;
        document.body.appendChild(t);
        setTimeout(function () { t.remove(); }, isError ? 8000 : 6000);
    }

    function saveNote(orderNumber, note, el) {
        var row = state.results.find(function (x) { return x.order_number === orderNumber; });
        if (!row) return;
        row.notes = note;
        row._noteSaving = true;
        row._noteStatus = t('Saving', 'Saving...');
        row._noteStatusError = false;
        render();

        beginOperation();
        jpost('save_note', { orderNumber: orderNumber, note: note }).then(function (data) {
            if (!data.ok) throw new Error(data.error || 'save_note returned ok=false');
            row._noteSaving = false;
            row._noteStatus = t('Saved', 'Saved');
            row._noteStatusError = false;
            row._noteEditing = false;
            row._noteDraft = undefined;
            render();
            setTimeout(function () {
                if (row._noteStatus === t('Saved', 'Saved')) {
                    row._noteStatus = '';
                    render();
                }
            }, 1600);
        }).catch(function (err) {
            row._noteSaving = false;
            row._noteStatus = t('SaveFailed', 'Save failed') + ': ' + err.message;
            row._noteStatusError = true;
            render();
            if (el) el.focus();
        }).then(endOperation, endOperation);
    }

    // ---------- Wiring ----------

    document.addEventListener('click', function (e) {
        var ap = e.target.closest('[data-approve]');
        if (ap) { e.preventDefault(); openApproveModal(ap.dataset.approve); return; }
        var cr = e.target.closest('[data-create]');
        if (cr) { e.preventDefault(); openCreateInvoiceModal(cr.dataset.create); return; }
        var ex = e.target.closest('[data-exclude]');
        if (ex) {
            e.preventDefault();
            var rowEx = state.results.find(function (x) { return x.order_number === ex.dataset.exclude; });
            if (!rowEx) return;
            // Guard: never let an exclude hide a real balance.
            if (Math.abs(Number(rowEx.diff || 0)) > 0.01) {
                showToast('Cannot exclude — this line has a non-zero balance (' + fmt(rowEx.diff) + '). Resolve it instead.', true);
                return;
            }
            rowEx._excluded = { at: 'manual' };
            rowEx.status = 'MATCH';
            rowEx.diff = 0;
            showToast('Excluded ' + esc(rowEx.order_number) + ' (zero balance — nothing to post).', false);
            render();
            return;
        }
        var noteEdit = e.target.closest('[data-note-edit]');
        if (noteEdit) {
            var rowEdit = state.results.find(function (x) { return x.order_number === noteEdit.dataset.noteEdit; });
            if (rowEdit) {
                rowEdit._noteEditing = true;
                rowEdit._noteDraft = rowEdit.notes || '';
                render();
            }
            return;
        }
        var noteCancel = e.target.closest('[data-note-cancel]');
        if (noteCancel) {
            var rowCancel = state.results.find(function (x) { return x.order_number === noteCancel.dataset.noteCancel; });
            if (rowCancel) {
                rowCancel._noteEditing = false;
                rowCancel._noteDraft = undefined;
                rowCancel._noteStatus = '';
                rowCancel._noteStatusError = false;
                render();
            }
            return;
        }
        var noteSave = e.target.closest('[data-note-save]');
        if (noteSave) {
            var rowSave = state.results.find(function (x) { return x.order_number === noteSave.dataset.noteSave; });
            if (rowSave) {
                saveNote(rowSave.order_number, rowSave._noteDraft || '', null);
            }
            return;
        }
        var chip = e.target.closest('.ebr-chip');
        if (chip) {
            document.querySelectorAll('.ebr-chip').forEach(function (c) { c.classList.remove('active'); });
            chip.classList.add('active');
            state.filter = chip.dataset.status;
            render();
            return;
        }
        var th = e.target.closest('#ebrTable th[data-key]');
        if (th) {
            var k = th.dataset.key;
            if (state.sortKey === k) state.sortDir *= -1;
            else { state.sortKey = k; state.sortDir = 1; }
            render();
            return;
        }
    });

    document.addEventListener('input', function (e) {
        var note = e.target.closest('.ebr-note-input');
        if (!note) return;
        var row = state.results.find(function (x) { return x.order_number === note.dataset.noteOrder; });
        if (!row) return;
        row._noteDraft = note.value;
    });

    var search = document.getElementById('ebrSearch');
    if (search) search.addEventListener('input', function (e) { state.query = e.target.value; render(); });
    var defaultSocidInput = document.getElementById('ebrDefaultSocid');
    if (defaultSocidInput) defaultSocidInput.addEventListener('input', selectedDefaultSocid);
    var changeCustomer = document.getElementById('ebrChangeDefaultCustomer');
    var customerSearchBox = document.getElementById('ebrCustomerSearch');
    var customerSearchInput = document.getElementById('ebrCustomerSearchInput');
    var customerPicker = changeCustomer ? changeCustomer.closest('.ebr-customer-picker') : null;
    var customerSearchTimer = null;
    if (changeCustomer && customerSearchBox && customerSearchInput) {
        changeCustomer.addEventListener('click', function () {
            customerSearchBox.hidden = !customerSearchBox.hidden;
            if (!customerSearchBox.hidden) {
                customerSearchInput.value = '';
                renderCustomerResults([]);
                searchCustomers('');
                customerSearchInput.focus();
            }
        });
        customerSearchInput.addEventListener('input', function () {
            var q = customerSearchInput.value.trim();
            if (customerSearchTimer) clearTimeout(customerSearchTimer);
            if (q.length < 2) {
                renderCustomerResults([]);
                return;
            }
            customerSearchTimer = setTimeout(function () { searchCustomers(q); }, 250);
        });
    }
    var customerResults = document.getElementById('ebrCustomerResults');
    if (customerResults) {
        customerResults.addEventListener('click', function (e) {
            var btn = e.target.closest('.ebr-customer-option');
            if (!btn || btn.disabled) return;
            setDefaultCustomer({
                id: btn.getAttribute('data-id'),
                label: btn.getAttribute('data-label'),
                name: btn.getAttribute('data-name'),
            });
        });
    }
    bindCustomerPickerClose(customerPicker, customerSearchBox);

    var bM = document.getElementById('ebrBulkApproveMatches');
    if (bM) bM.addEventListener('click', runBulkApproveMatches);
    var bA = document.getElementById('ebrBulkApprove');
    if (bA) bA.addEventListener('click', runBulkApprove);
    var bC = document.getElementById('ebrBulkCreate');
    if (bC) bC.addEventListener('click', runBulkCreate);
    var bX = document.getElementById('ebrBulkExclude');
    if (bX) bX.addEventListener('click', runBulkExclude);
    var bP = document.getElementById('ebrBulkPay');
    if (bP) bP.addEventListener('click', runBulkPay);
    var bSave = document.getElementById('ebrSaveDraft');
    if (bSave) bSave.addEventListener('click', saveDraft);

    var dlCsv = document.getElementById('ebrDlCsv');
    if (dlCsv) dlCsv.addEventListener('click', downloadCsv);
    var dlJson = document.getElementById('ebrDlJson');
    if (dlJson) dlJson.addEventListener('click', downloadJson);

    function downloadCsv() {
        var report = window.EBR_EXPORT.build(state.results, state.totals, state.payout, state.sourceFile, { defaultSocid: selectedDefaultSocid(), defaultCustomerLabel: selectedDefaultCustomerLabel() });
        var blob = new Blob([window.EBR_EXPORT.toCsv(report)], { type: 'text/csv;charset=utf-8' });
        triggerDownload(blob, exportFilename('csv'));
    }
    function downloadJson() {
        var report = window.EBR_EXPORT.build(state.results, state.totals, state.payout, state.sourceFile, { defaultSocid: selectedDefaultSocid(), defaultCustomerLabel: selectedDefaultCustomerLabel() });
        var blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
        triggerDownload(blob, exportFilename('json'));
    }
    function exportFilename(ext) {
        var base = state.sourceFile ? state.sourceFile.replace(/\.csv$/i, '') : 'reconcile';
        return base + '-reconcile-report.' + ext;
    }
    function triggerDownload(blob, filename) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }

    // Kick off first render
    render();
})();
