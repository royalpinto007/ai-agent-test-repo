<?php
/**
 * eBay payout reconciliation — main page.
 *
 * GET  : show the upload form (and the in-memory last result, if any in $_SESSION).
 * POST (with file): parse the CSV, run reconciliation, render results.
 */

// Load Dolibarr environment (htdocs/custom/ebayreconcile/reconcile.php → up 3 levels to htdocs)
$res = 0;
if (!$res && file_exists("../main.inc.php"))       $res = @include "../main.inc.php";
if (!$res && file_exists("../../main.inc.php"))    $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/custom/ebayreconcile/class/EbayReconciler.class.php';
require_once DOL_DOCUMENT_ROOT.'/custom/ebayreconcile/lib/ebayreconcile.lib.php';

global $langs, $user, $conf, $db;
$langs->loadLangs(array('ebayreconcile@ebayreconcile', 'main', 'errors'));

// Permission gate
if (empty($user->rights->ebayreconcile->use)) accessforbidden();

$action = GETPOST('action', 'aZ09');
$setupDefaultSocid = !empty($conf->global->EBAYRECONCILE_DEFAULT_SOCID) ? (int) $conf->global->EBAYRECONCILE_DEFAULT_SOCID : 0;

function ebr_customer_label($db, $socid)
{
    $socid = (int) $socid;
    if ($socid <= 0) return '';
    require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
    $soc = new Societe($db);
    if ($soc->fetch($socid) <= 0) return '#'.$socid;
    return $soc->name.' (#'.$socid.')';
}

$reconcileResult = null;
$reconcileError = null;

// Handle CSV upload
if ($action === 'reconcile' && !empty($_FILES['payoutcsv']['tmp_name'])) {
    $tmp = $_FILES['payoutcsv']['tmp_name'];
    $name = $_FILES['payoutcsv']['name'];
    $content = file_get_contents($tmp);
    if ($content === false) {
        $reconcileError = "Could not read uploaded file";
    } else {
        try {
            $reconciler = new EbayReconciler($db);
            $reconcileResult = $reconciler->reconcileCsv($content);
            $reconcileResult['source_file'] = $name;
            $reconcileResult['default_socid'] = GETPOST('default_socid', 'int') ?: $setupDefaultSocid;
            // Stash in session so the action.php handlers can read payout metadata and per-row context
            // without re-uploading the CSV.
            $_SESSION['ebayreconcile_lastrun'] = $reconcileResult;
        } catch (Exception $e) {
            $reconcileError = $e->getMessage();
        }
    }
}

// Resume an in-progress draft (?draft=ID): rebuild the reconcile result from the
// saved state so the user continues exactly where they left off — no re-upload.
$loadedDraftId = 0;
if ($reconcileResult === null && GETPOST('draft', 'int')) {
    $draftId = GETPOST('draft', 'int');
    $sqld  = "SELECT rowid, payout_id, state_json FROM ".MAIN_DB_PREFIX."ebayreconcile_payout";
    $sqld .= " WHERE rowid = ".((int)$draftId)." AND entity IN (".getEntity('facture').") AND status = 'draft'";
    $rsd = $db->query($sqld);
    if ($rsd && ($o = $db->fetch_object($rsd))) {
        $state = json_decode($o->state_json, true);
        if (is_array($state) && !empty($state['results']) && is_array($state['results'])) {
            $results = $state['results'];
            // Re-derive the count chips from the saved rows; merge saved tie-out totals.
            $counts = array('ordersCompared' => 0, 'matches' => 0, 'mismatches' => 0,
                'missingInDolibarr' => 0, 'noLinkedInvoices' => 0, 'noOrderNumber' => 0);
            foreach ($results as $row) {
                $counts['ordersCompared']++;
                switch (isset($row['status']) ? $row['status'] : '') {
                    case 'MATCH':               $counts['matches']++; break;
                    case 'MISMATCH':            $counts['mismatches']++; break;
                    case 'MISSING_IN_DOLIBARR': $counts['missingInDolibarr']++; break;
                    case 'NO_LINKED_INVOICES':  $counts['noLinkedInvoices']++; break;
                    case 'NO_ORDER_NUMBER':     $counts['noOrderNumber']++; break;
                }
            }
            $savedTotals = (isset($state['totals']) && is_array($state['totals'])) ? $state['totals'] : array();
            $reconcileResult = array(
                'summary'     => array_merge($counts, $savedTotals),
                'payout'      => isset($state['payout']) ? $state['payout'] : null,
                'results'     => $results,
                'source_file' => isset($state['sourceFile']) ? $state['sourceFile'] : null,
                'default_socid' => !empty($state['defaultSocid']) ? (int) $state['defaultSocid'] : $setupDefaultSocid,
            );
            $_SESSION['ebayreconcile_lastrun'] = $reconcileResult;
            $loadedDraftId = (int) $o->rowid;
            setEventMessages($langs->trans("DraftResumed", dol_escape_htmltag($o->payout_id)), null, 'mesgs');
        } else {
            setEventMessages($langs->trans("DraftLoadFailed"), null, 'warnings');
        }
    }
}

// Header — uses Dolibarr's standard chrome
llxHeader('', $langs->trans("ReconcilePageTitle"), '');

// Cache-bust assets by file mtime so a redeploy always reloads them (avoids a
// stale cached JS rendering against newer server HTML — e.g. a shifted table).
$ebrCssV = (int) @filemtime(dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 0));
print '<link rel="stylesheet" href="'.dol_buildpath('/ebayreconcile/css/ebayreconcile.css', 1).'?v='.$ebrCssV.'" />';

// Topbar (Dolibarr's print_fiche_titre is the canonical h1 here)
print load_fiche_titre($langs->trans("ReconcilePageTitle"), '', 'bank_account');

// --- Upload card ---
print '<div class="fichecenter ebr-card">';
print '  <div class="ebr-titrebar">';
print '    <i class="fa fa-file-upload"></i> '.$langs->trans("UploadPayoutCsv");
print '  </div>';
print '  <div class="ebr-body">';
print '    <form method="POST" enctype="multipart/form-data" id="ebrUploadForm">';
print '      <input type="hidden" name="token" value="'.newToken().'"/>';
print '      <input type="hidden" name="action" value="reconcile"/>';
print '      <label class="ebr-dropzone">';
print '        <i class="fa fa-cloud-upload-alt"></i>';
print '        <div class="ebr-dz-text">';
print '          <div class="ebr-t1">'.$langs->trans("DropOrBrowse").'</div>';
print '          <div class="ebr-t2">'.$langs->trans("PayoutMatchExplain").'</div>';
print '          <div class="ebr-selected-file" id="ebrSelectedFile">'.$langs->trans("NoFileSelected").'</div>';
print '        </div>';
print '        <input type="file" name="payoutcsv" accept=".csv,text/csv" required />';
print '      </label>';
print '      <div class="ebr-default-customer ebr-default-customer-upload" id="ebrUploadDefaultCustomerBlock"'.($reconcileResult ? ' hidden' : '').'>';
print '        <label id="ebrUploadDefaultCustomerTitle">'.$langs->trans("DefaultCustomerForUnmatchedDocs").'</label>';
print '        <span class="ebr-default-customer-current" id="ebrUploadDefaultCustomerLabel">'.dol_escape_htmltag(ebr_customer_label($db, $setupDefaultSocid)).'</span>';
print '        <input type="hidden" name="default_socid" id="ebrUploadDefaultSocid" value="'.$setupDefaultSocid.'" />';
print '        <input type="hidden" id="ebrUploadSetupDefaultSocid" value="'.$setupDefaultSocid.'" />';
print '        <span class="ebr-customer-picker">';
print '        <button class="button" type="button" id="ebrUploadChangeDefaultCustomer">'.$langs->trans("ChangeCustomer").'</button>';
print '        <div class="ebr-customer-search" id="ebrUploadCustomerSearch" hidden>';
print '          <input type="search" id="ebrUploadCustomerSearchInput" placeholder="'.dol_escape_htmltag($langs->trans("SearchCustomerPlaceholder")).'" autocomplete="off" />';
print '          <div class="ebr-customer-results" id="ebrUploadCustomerResults"></div>';
print '        </div>';
print '        </span>';
print '        <span class="ebr-sub">'.$langs->trans("DefaultCustomerForUnmatchedDocsHelp").'</span>';
print '      </div>';
print '      <div style="margin-top:12px">';
print '        <button class="butAction" type="submit">'.$langs->trans("Reconcile").'</button>';
print '      </div>';
print '    </form>';
if ($reconcileError) {
    print '    <div class="ebr-error"><i class="fa fa-exclamation-triangle"></i> '.dol_escape_htmltag($reconcileError).'</div>';
}
print '  </div>';
print '</div>';

// --- If we have a result, render summary + table ---
if ($reconcileResult) {
    $summary = $reconcileResult['summary'];
    $payout  = $reconcileResult['payout'];
    $results = $reconcileResult['results'];

    // Already-reconciled guard: if this payout was previously settled, we must NOT
    // offer to reconcile/pay it again (that would double-record payments). Look it up
    // by payout id and, if found, render the page READ-ONLY with a clear banner +
    // link to the history record. We only block on settled rows, never drafts.
    $alreadySettled = null;
    if ($payout && !empty($payout['id'])) {
        $sqls  = "SELECT rowid, payout_date, payments_count, total_paid, settled_at, settled_by, csv_filename, state_json";
        $sqls .= " FROM ".MAIN_DB_PREFIX."ebayreconcile_payout";
        $sqls .= " WHERE entity IN (".getEntity('facture').")";
        $sqls .= " AND status = 'settled'";
        $sqls .= " AND payout_id = '".$db->escape((string) $payout['id'])."'";
        $sqls .= " ORDER BY settled_at DESC";
        $sqls .= $db->plimit(1);
        $rss = $db->query($sqls);
        if ($rss && ($so = $db->fetch_object($rss))) {
            $byName = '';
            if ($so->settled_by) {
                $u = new User($db);
                if ($u->fetch((int) $so->settled_by) > 0) $byName = $u->getFullName($langs);
            }
            $alreadySettled = array(
                'rowid'          => (int) $so->rowid,
                'payments_count' => (int) $so->payments_count,
                'total_paid'     => (float) $so->total_paid,
                'settled_at'     => $db->jdate($so->settled_at),
                'by'             => $byName,
            );

            // Replay the reconciled state it was settled in (all rows resolved) rather
            // than the fresh re-match — re-matching now-paid invoices would falsely
            // show mismatches because paid invoices have 0 remaining due. Mirrors the
            // draft-resume rebuild.
            $sstate = json_decode($so->state_json, true);
            if (is_array($sstate) && !empty($sstate['results']) && is_array($sstate['results'])) {
                $sresults = $sstate['results'];
                $scounts = array('ordersCompared' => 0, 'matches' => 0, 'mismatches' => 0,
                    'missingInDolibarr' => 0, 'noLinkedInvoices' => 0, 'noOrderNumber' => 0);
                foreach ($sresults as $srow) {
                    $scounts['ordersCompared']++;
                    switch (isset($srow['status']) ? $srow['status'] : '') {
                        case 'MATCH':               $scounts['matches']++; break;
                        case 'MISMATCH':            $scounts['mismatches']++; break;
                        case 'MISSING_IN_DOLIBARR': $scounts['missingInDolibarr']++; break;
                        case 'NO_LINKED_INVOICES':  $scounts['noLinkedInvoices']++; break;
                        case 'NO_ORDER_NUMBER':     $scounts['noOrderNumber']++; break;
                    }
                }
                $ssaved = (isset($sstate['totals']) && is_array($sstate['totals'])) ? $sstate['totals'] : array();
                $reconcileResult = array(
                    'summary'     => array_merge($scounts, $ssaved),
                    'payout'      => isset($sstate['payout']) ? $sstate['payout'] : $payout,
                    'results'     => $sresults,
                    'source_file' => isset($sstate['sourceFile']) ? $sstate['sourceFile'] : (isset($reconcileResult['source_file']) ? $reconcileResult['source_file'] : null),
                    'default_socid' => !empty($sstate['defaultSocid']) ? (int) $sstate['defaultSocid'] : (!empty($reconcileResult['default_socid']) ? (int) $reconcileResult['default_socid'] : $setupDefaultSocid),
                );
                $_SESSION['ebayreconcile_lastrun'] = $reconcileResult;
                // Re-point the local render vars at the replayed state.
                $summary = $reconcileResult['summary'];
                $payout  = $reconcileResult['payout'];
                $results = $reconcileResult['results'];
            }
        }
    }

    // Already-reconciled banner — shown above everything; the rest of the page is
    // forced read-only (writePerm=false in the bootstrap below).
    if ($alreadySettled) {
        $histUrl = dol_buildpath('/ebayreconcile/history.php', 1).'?payout_id='.urlencode((string) $payout['id']);
        print '<div class="ebr-alreadybanner">';
        print '<i class="fa fa-check-circle"></i> ';
        print '<strong>'.$langs->trans("AlreadyReconciledTitle").'</strong> ';
        print '<span class="ebr-sub">'.$langs->trans("AlreadyReconciledDetail",
            dol_print_date($alreadySettled['settled_at'], 'dayhour'),
            $alreadySettled['by'] !== '' ? $alreadySettled['by'] : '?',
            (string) $alreadySettled['payments_count'],
            price($alreadySettled['total_paid'])).'</span> ';
        print '<a class="butAction" href="'.$histUrl.'">'.$langs->trans("ViewInHistory").'</a>';
        print '</div>';
    }

    // Summary tiles
    print '<div class="ebr-tiles">';
    $tiles = array(
        array($langs->trans("Orders"),           (int)$summary['ordersCompared'],   '',         'ALL'),
        array($langs->trans("Matches"),          (int)$summary['matches'],          'match',    'MATCH'),
        array($langs->trans("Mismatches"),       (int)$summary['mismatches'],       'mismatch', 'MISMATCH'),
        array($langs->trans("MissingInDolibarr"),(int)$summary['missingInDolibarr'],'missing',  'MISSING_IN_DOLIBARR'),
        array($langs->trans("NoLinkedInvoices"), (int)$summary['noLinkedInvoices'], 'noinv',    'NO_LINKED_INVOICES'),
        array($langs->trans("NoOrderNumber"),    (int)$summary['noOrderNumber'],    'noorder',  'NO_ORDER_NUMBER'),
    );
    foreach ($tiles as $t) {
        list($label, $num, $cls, $statusKey) = $t;
        print '<div class="ebr-tile '.$cls.'">';
        print '<div class="ebr-lbl">'.dol_escape_htmltag($label).'</div>';
        print '<div class="ebr-num" data-tile="'.$statusKey.'">'.(int)$num.'</div>';
        print '</div>';
    }
    print '</div>';

    // Payout banner
    if ($payout) {
        print '<div class="ebr-payoutbanner">';
        print '<i class="fa fa-coins"></i> ';
        if (!empty($reconcileResult['source_file'])) {
            print '<span class="ebr-sub"><strong>File:</strong> '.dol_escape_htmltag($reconcileResult['source_file']).'</span> &middot; ';
        }
        print 'Payout <code>'.dol_escape_htmltag($payout['id']).'</code> &middot; ';
        print dol_escape_htmltag($payout['date']).' &middot; ';
        print dol_escape_htmltag($payout['method']);
        print '</div>';
    }

    $selectedDefaultSocid = !empty($reconcileResult['default_socid']) ? (int) $reconcileResult['default_socid'] : $setupDefaultSocid;
    $selectedDefaultCustomerLabel = ebr_customer_label($db, $selectedDefaultSocid);
    print '<input type="hidden" id="ebrDefaultSocid" value="'.$selectedDefaultSocid.'" />';
    print '<span id="ebrDefaultCustomerLabel" hidden>'.dol_escape_htmltag($selectedDefaultCustomerLabel).'</span>';
    print '<div class="ebr-default-customer ebr-default-customer-summary">';
    print '<label>'.($selectedDefaultSocid === $setupDefaultSocid ? $langs->trans("DefaultCustomerForUnmatchedDocs") : $langs->trans("SelectedCustomerForUnmatchedDocs")).'</label>';
    print '<span class="ebr-default-customer-current">'.dol_escape_htmltag($selectedDefaultCustomerLabel).'</span>';
    print '<span class="ebr-sub">'.$langs->trans("DefaultCustomerForUnmatchedDocsHelp").'</span>';
    print '</div>';

    // Tie-out summary — the same equation as the CSV, recomputed LIVE by the JS as
    // documents are created/approved/paid (the JS fills these on load and after every
    // action). One status, no contradictory second tie line.
    if (isset($summary['netPayout'])) {
        print '<div class="ebr-tieout">';
        print '<div class="ebr-tieout-state pending" id="ebrTieState"><i class="fa fa-exclamation-circle"></i> '.$langs->trans("NotYetReconciled").'</div>';
        print '<div class="ebr-tieout-figs">';
        print '<div class="ebr-tieout-fig pos"><span class="ebr-tieout-lbl">'.$langs->trans("GrossSales").'</span><span class="ebr-tieout-val" id="ebrTieGross">-</span></div>';
        print '<div class="ebr-tieout-fig pos"><span class="ebr-tieout-lbl">'.$langs->trans("TotalDebits").'</span><span class="ebr-tieout-val" id="ebrTieDebits">-</span></div>';
        print '<div class="ebr-tieout-fig neg"><span class="ebr-tieout-lbl">'.$langs->trans("TotalCredits").'</span><span class="ebr-tieout-val" id="ebrTieCredits">-</span></div>';
        print '<div class="ebr-tieout-fig net"><span class="ebr-tieout-lbl">'.$langs->trans("NetPayout").'</span><span class="ebr-tieout-val" id="ebrTieNet">-</span></div>';
        print '<div class="ebr-tieout-fig stated"><span class="ebr-tieout-lbl">'.$langs->trans("EbayPayoutAmount").'</span><span class="ebr-tieout-val" id="ebrTiePayout">-</span></div>';
        print '<div class="ebr-tieout-fig"><span class="ebr-tieout-lbl">'.$langs->trans("Difference").'</span><span class="ebr-tieout-val" id="ebrTieDiff">-</span></div>';
        print '</div>';
        print '<div class="ebr-tieout-check" id="ebrFileTieCheck"></div>';
        print '<div class="ebr-tieout-hint">'.$langs->trans("TieOutHint").'</div>';
        print '</div>';
    }

    // Toolbar — filters + bulk actions + downloads
    print '<div class="fichecenter ebr-card" id="ebrTablePanel">';
    print '<div class="ebr-titrebar">';
    print '<i class="fa fa-list"></i> Orders ';
    print '<span class="ebr-spacer"></span>';
    if ($user->rights->ebayreconcile->write && empty($alreadySettled)) {
        print '<button class="butAction" id="ebrBulkApproveMatches" type="button" hidden>Approve all match adjustments</button>';
        print '<button class="butAction" id="ebrBulkApprove" type="button" hidden>'.$langs->trans("ApproveAllMismatches").'</button>';
        print '<button class="butAction" id="ebrBulkCreate" type="button" hidden>Create all documents</button>';
        print '<button class="butAction" id="ebrBulkExclude" type="button" hidden>Exclude all zero-balance</button>';
        print '<button class="button" id="ebrSaveDraft" type="button" title="'.dol_escape_htmltag($langs->trans("SaveDraftHelp")).'"><i class="fa fa-save"></i> '.$langs->trans("SaveDraft").' <span id="ebrDraftStatus" class="ebr-draft-status"></span></button>';
        print '<button class="butAction" id="ebrBulkPay" type="button" hidden>'.$langs->trans("PayAll").'</button>';
    }
    print '<button class="button" id="ebrDlCsv"  type="button">CSV</button> ';
    print '<button class="button" id="ebrDlJson" type="button">JSON</button>';
    print '</div>';
    print '<div class="ebr-body">';

    print '<div class="ebr-helpbox">';
    print '<div class="ebr-helpbox-title"><i class="fa fa-info-circle"></i> '.$langs->trans("ReconcileHelpTitle").'</div>';
    print '<ul class="ebr-helpbox-list">';
    print '<li>'.$langs->trans("ReconcileHelpPoint1").'</li>';
    print '<li>'.$langs->trans("ReconcileHelpPoint2").'</li>';
    print '<li>'.$langs->trans("ReconcileHelpPoint3").'</li>';
    print '<li>'.$langs->trans("ReconcileHelpPoint4").'</li>';
    print '<li>'.$langs->trans("ReconcileHelpPoint5").'</li>';
    print '<li>'.$langs->trans("ReconcileHelpPoint6").'</li>';
    print '</ul>';
    print '</div>';

    // Filters
    print '<div class="ebr-filters">';
    print '<input type="search" id="ebrSearch" placeholder="Search by order, SO ref, invoice ref..." />';
    print ' <span class="ebr-chip active" data-status="ALL">All <span class="ebr-count" data-count="ALL">0</span></span>';
    print ' <span class="ebr-chip" data-status="MATCH">'.$langs->trans('StatusMATCH').' <span class="ebr-count" data-count="MATCH">0</span></span>';
    print ' <span class="ebr-chip" data-status="MISMATCH">'.$langs->trans('StatusMISMATCH').' <span class="ebr-count" data-count="MISMATCH">0</span></span>';
    print ' <span class="ebr-chip" data-status="MISSING_IN_DOLIBARR">'.$langs->trans('StatusMISSING_IN_DOLIBARR').' <span class="ebr-count" data-count="MISSING_IN_DOLIBARR">0</span></span>';
    print ' <span class="ebr-chip" data-status="NO_LINKED_INVOICES">'.$langs->trans('StatusNO_LINKED_INVOICES').' <span class="ebr-count" data-count="NO_LINKED_INVOICES">0</span></span>';
    print ' <span class="ebr-chip" data-status="NO_ORDER_NUMBER">'.$langs->trans('StatusNO_ORDER_NUMBER').' <span class="ebr-count" data-count="NO_ORDER_NUMBER">0</span></span>';
    print '</div>';

    // The table
    print '<div class="ebr-tablewrap">';
    print '<table class="liste ebr-table" id="ebrTable">';
    print '<thead><tr class="liste_titre">';
    print '<th data-key="status">'.$langs->trans("ColStatus").'</th>';
    print '<th data-key="order_number">'.$langs->trans("ColOrderNumber").'</th>';
    print '<th data-key="ebay_type">'.$langs->trans("ColEbayType").'</th>';
    print '<th data-key="ebay_net" class="num">'.$langs->trans("ColEbayNet").'</th>';
    print '<th data-key="dolibarr_net" class="num">'.$langs->trans("ColDolibarrNet").'</th>';
    print '<th data-key="diff" class="num">'.$langs->trans("ColDiff").'</th>';
    print '<th data-key="dolibarr_order_ref">'.$langs->trans("ColSORef").'</th>';
    print '<th data-key="invoice_refs">'.$langs->trans("ColInvoices").'</th>';
    print '<th data-key="notes" class="ebr-col-notes">'.$langs->trans("ColNotes").'</th>';
    print '<th>'.$langs->trans("ColAction").'</th>';
    print '</tr></thead>';
    print '<tbody id="ebrTbody"></tbody>';
    print '</table>';
    print '<div id="ebrEmpty" class="ebr-empty" hidden>No rows match the current filter.</div>';
    print '</div>';

    print '</div>'; // /ebr-body
    print '</div>'; // /fichecenter

    // Bootstrap state for the JS
    $bootstrap = array(
        'results'              => $results,
        'payout'               => $payout,
        'totals'               => array(
            'grossSales'   => isset($summary['grossSales']) ? (float)$summary['grossSales'] : null,
            'debits'       => isset($summary['debits'])     ? (float)$summary['debits']     : null,
            'credits'      => isset($summary['credits'])    ? (float)$summary['credits']    : null,
            'netPayout'    => isset($summary['netPayout'])  ? (float)$summary['netPayout']  : null,
            'statedPayout' => isset($summary['statedPayout']) ? $summary['statedPayout'] : null,
            'tiesOut'      => isset($summary['tiesOut']) ? $summary['tiesOut'] : null,
            'tieDiff'      => isset($summary['tieDiff']) ? $summary['tieDiff'] : null,
        ),
        'sourceFile'           => $reconcileResult['source_file'],
        'setupDefaultSocid'    => $setupDefaultSocid,
        'defaultSocid'         => $selectedDefaultSocid,
        'defaultCustomerLabel' => $selectedDefaultCustomerLabel,
        // Read-only when the payout is already settled — no re-reconcile, no re-pay.
        'writePerm'            => !empty($user->rights->ebayreconcile->write) && empty($alreadySettled),
        'alreadySettled'       => !empty($alreadySettled),
        'invoiceUrlTemplate'   => DOL_URL_ROOT.'/compta/facture/card.php?id={id}',
        'orderUrlTemplate'     => DOL_URL_ROOT.'/commande/card.php?id={id}',
        'actionUrl'            => dol_buildpath('/ebayreconcile/action.php', 1),
        'listUrl'              => dol_buildpath('/ebayreconcile/list.php', 1),
        'draftId'              => $loadedDraftId,
        'token'                => newToken(),
        'i18n'                 => array(
            'NotesPlaceholder' => $langs->trans("NotesPlaceholder"),
            'Saving'           => $langs->trans("Saving"),
            'Saved'            => $langs->trans("Saved"),
            'SaveFailed'       => $langs->trans("SaveFailed"),
            'SaveDraftHelp'    => $langs->trans("SaveDraftHelp"),
        ),
    );
    print '<script>window.EBR_BOOT = '.json_encode($bootstrap).';</script>';
}

print '<script>window.EBR_UPLOAD_I18N = '.json_encode(array(
    'NoFileSelected' => $langs->trans("NoFileSelected"),
    'SelectedFile'   => $langs->trans("SelectedFile"),
    'AddNote'        => $langs->trans("AddNote"),
    'EditNote'       => $langs->trans("EditNote"),
    'SaveNote'       => $langs->trans("SaveNote"),
    'Cancel'         => $langs->trans("Cancel"),
    'DefaultCustomerForUnmatchedDocs' => $langs->trans("DefaultCustomerForUnmatchedDocs"),
    'SelectedCustomerForUnmatchedDocs' => $langs->trans("SelectedCustomerForUnmatchedDocs"),
    'actionUrl'      => dol_buildpath('/ebayreconcile/action.php', 1),
    'token'          => newToken(),
)).';</script>';

// JS for exports, filters / sorting / bulk + per-row actions
$ebrExportJsV = (int) @filemtime(dol_buildpath('/ebayreconcile/js/ebayreconcile-export.js', 0));
print '<script src="'.dol_buildpath('/ebayreconcile/js/ebayreconcile-export.js', 1).'?v='.$ebrExportJsV.'"></script>';
$ebrJsV = (int) @filemtime(dol_buildpath('/ebayreconcile/js/ebayreconcile.js', 0));
print '<script src="'.dol_buildpath('/ebayreconcile/js/ebayreconcile.js', 1).'?v='.$ebrJsV.'"></script>';

llxFooter();
$db->close();
